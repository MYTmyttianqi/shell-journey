"use strict";
const $=s=>document.querySelector(s),c=$("canvas"),g=c.getContext("2d"),img={},maps={};
const family=[["bat","星翼蝠"],null,["crab","潮甲兽"]];
const realms={rift:{name:"幽晶裂隙",units:["spectre","deathknight","skeleton2"],names:["游魂","幽甲骑士","骨冠守卫"],xp:2},ember:{name:"烬火王庭",units:["deathknight","spectre","boss"],names:["烬卫","焰魂","余烬领主"],xp:4}};
const key="shell-journey.realms.v1";
function read(k){try{return JSON.parse(localStorage.getItem(k))||{}}catch{return {}}}
const old=read("shell-journey.watch.v1"),earlier=read("shell-journey.care.v1");
let pet=read(key);
if(pet.form===1){pet.form=0;store()}
if(!family[pet.form]||!Number.isFinite(pet.xp)){
 const seed=Number.isInteger(earlier.seed)?earlier.seed>>>0:crypto.getRandomValues(new Uint32Array(1))[0];
 let petName=["暮铃","星珀","青烬","露眠","岚羽","霜灯"][seed%6];
 if(earlier.pet&&["tail","shell"].includes(earlier.pet.rig)){
 let a=(seed^0x77159203)>>>0;function next(){a=(a+0x6d2b79f5)>>>0;let t=Math.imul(a^(a>>>15),a|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296}
 petName=(earlier.pet.rig==="shell"?"藏伏砚眠玄岫":"游轻拾松望野")[Math.floor(next()*6)]+"苔露砾眠泠栖岚微穗霜棠禾"[Math.floor(next()*12)];
 }
 pet={name:petName,form:2*(Math.floor(seed/11)%2),xp:0,blade:!!old.blade,herbs:Math.max(0,Number(old.tonics)||0),wins:0};store()
}
function store(){try{localStorage.setItem(key,JSON.stringify(pet))}catch{}}
const lv=()=>1+Math.min(5,Math.floor(pet.xp/4)),maxHp=()=>8+lv(),beast=()=>family[pet.form][0];
let mode="home",realm="rift",stage=0,hp=0,foeHp=0,charge=0,turn=0,t=0,motion="",motionStart=-5,lock=false,lastMessage="",generation=0;
const here=()=>realms[realm],intent=()=>["蓄力","重击","试探"][(turn+stage+(realm==="ember"?1:0))%3];
function ui(place,status,title,note,actions){
 $("#place").textContent=place;$("#status").textContent=status;$("#name").textContent=title;$("#hint").textContent=note;
 const buttons=actions.map(([label,run,disabled])=>{const b=document.createElement("button");const icon={"出门踏瓦":"default_mese_crystal","探索矿谷":"default_tool_steelpick","我的行囊":"default_book","秘境试炼":"default_tool_steelsword","开启宝匣":"default_chest_front","斩击":"default_tool_steelsword","兽技 · 2":"default_mese_crystal"}[label];if(icon)b.append(iconImage(icon));b.append(label);b.disabled=!!disabled;b.onclick=run;return b});$("nav").replaceChildren(...buttons);
}
function home(message=""){
 mode="home";$("main").dataset.mode="home";$("#log").textContent="";lock=false;generation++;
 ui("",pet.name,paths[trail.path].name,message||paths[trail.path].summary, [["Enter the Vault",enterArena],["出门踏瓦",startRoof],["我的行囊",journal]]);
}
function choose(){$("main").dataset.mode="choose";mode="choose";ui("灵兽栖境","同行 · "+pet.name,"选择秘境","幽晶裂隙较平缓。烬火王庭的重击更强，羁绊奖励翻倍。",[["幽晶裂隙",()=>start("rift")],["烬火王庭",()=>start("ember")],["返回",()=>home()]])}
function start(r){realm=r;stage=0;hp=maxHp();charge=1;encounter()}
function encounter(){turn=0;foeHp=4+stage*2+(realm==="ember"?2:0);mode="fight";lastMessage="";showFight()}
function showFight(){
 const tell=intent(),advice={"蓄力":"斩击可打断蓄力","重击":"格挡可化解重击","试探":"可用斩击抢攻"}[tell];
 ui(here().name+"　"+(stage+1)+"/3","体力 "+hp+"/"+maxHp()+"　灵能 "+charge+"/3",here().names[stage]+" · "+foeHp+" 体力",[lastMessage,"敌方"+tell+"，"+advice+"。"].filter(Boolean).join(" "),
 [["斩击",()=>move("slash"),lock],["格挡",()=>move("guard"),lock],["兽技 · 2",()=>move("skill"),lock||charge<2]])
}
function animate(type){motion=type;motionStart=t}
function move(action){
 if(lock||mode!=="fight"||(action==="skill"&&charge<2))return;
 const tell=intent();let dealt=0,hurt=0;lock=true;
 if(action==="guard"){charge=Math.min(3,charge+2);dealt=tell==="重击"?2:0;lastMessage=dealt?"格挡反震，敌方受到 2 点伤害。":"守势聚集了灵能。"}
 else if(action==="skill"){charge-=2;dealt=3+lv();lastMessage=pet.name+" 突袭，造成 "+dealt+" 点伤害。"}
 else{charge=Math.min(3,charge+1);dealt=(pet.blade?3:2)+(tell==="蓄力"?1:0);lastMessage=tell==="蓄力"?"打断成功。":"剑击命中。"}
 foeHp=Math.max(0,foeHp-dealt);
 if(foeHp>0&&action==="slash"&&tell!=="蓄力")hurt=tell==="重击"?(realm==="ember"?5:4):1;
 hp=Math.max(0,hp-hurt);if(hurt)lastMessage+=" 受到 "+hurt+" 点反击。";
 if(!hp&&pet.herbs>0){pet.herbs--;hp=4;store();lastMessage+=" 药剂恢复了体力。"}
 animate(action);showFight();const id=generation;
 setTimeout(()=>{if(id!==generation)return;lock=false;
 if(!hp){home("这次远征止步于"+here().names[stage]+"。灵兽已陪你回到栖境。");return}
 if(!foeHp){mode="rest";animate("victory");if(stage===2){ui(here().name,"已肃清","秘境宝匣","灵兽守住了宝匣，开启它领取本次远征的奖励。",[["开启宝匣",reward]])}
 else ui(here().name,"体力 "+hp+"/"+maxHp(),"短暂休整","下一战之前，选择恢复 3 点体力，或带着充满的灵能进场。",[["休整回血",()=>advance(true)],["积蓄灵能",()=>advance(false)]]);return}
 turn++;showFight()
 },520)
}
function advance(heal){if(heal)hp=Math.min(maxHp(),hp+3);else charge=3;stage++;encounter()}
function reward(){if(mode!=="rest")return;pet.xp+=here().xp;pet.wins++;let prize;
 if(!pet.blade&&Math.random()<.4){pet.blade=true;prize="蓝钢剑已装备"}else{pet.herbs++;prize="获得一瓶救命药剂"}store();home("远征归来 · "+prize+"，羁绊经验 +"+here().xp+"。")}
function fit(){const scale=Math.max(2,Math.ceil(Math.max(innerWidth/420,innerHeight/295)));c.width=Math.ceil(innerWidth/scale);c.height=Math.ceil(innerHeight/scale);g.imageSmoothingEnabled=false}
function bake(scene){
 const layer=document.createElement("canvas");layer.width=scene.cols*16;layer.height=scene.rows*16;
 const p=layer.getContext("2d"),tiles=img.tilesheet,cols=tiles.width/16;
 scene.tiles.forEach((v,i)=>{for(const tile of [].concat(v)){if(!tile)continue;const k=tile-1;p.drawImage(tiles,k%cols*16,Math.floor(k/cols)*16,16,16,i%scene.cols*16,Math.floor(i/scene.cols)*16,16,16)}});return layer;
}
function sprite(id,anim,x,y,scale=1,flip=false,time=t){
 const d=DATA.sprites[id],a=d.animations[anim]||d.animations.idle_down,frame=Math.floor(time*8)%a.length;g.save();g.translate(Math.round(x),Math.round(y));g.scale(flip?-scale:scale,scale);g.drawImage(img[id],frame*d.width,a.row*d.height,d.width,d.height,(d.offset_x||0)-8,(d.offset_y||0)-8,d.width,d.height);g.restore()
}
function glow(x,y,r,color){const grad=g.createRadialGradient(x,y,0,x,y,r);grad.addColorStop(0,color);grad.addColorStop(1,"transparent");g.fillStyle=grad;g.fillRect(x-r,y-r,2*r,2*r)}
function render(now){
 const dt=Math.min(.035,Math.max(0,now/1000-t));t=now/1000;if(mode==="studio"){paintSample();requestAnimationFrame(render);return}if(mode==="portrait"||mode==="armory"){paintPortrait();requestAnimationFrame(render);return}if(mode==="arena"){arenaFrame(dt);requestAnimationFrame(render);return}if(mode==="home"||mode==="journal"){paintPortrait();requestAnimationFrame(render);return}if(mode==="roof"){roofFrame(dt);requestAnimationFrame(render);return}if(mode==="field"){fieldFrame(dt);requestAnimationFrame(render);return}const w=c.width,h=c.height,homeScene=["home","choose","journal"].includes(mode),scene=maps[homeScene?"grove":realm];
 const cx=Math.round(w*.5),cy=Math.round(h*.47),age=t-motionStart,pulse=age<.55?Math.sin(Math.PI*age/.55):0;
 g.drawImage(scene,cx-scene.width/2,cy-scene.height/2);
 g.fillStyle=homeScene?"#25314f55":realm==="rift"?"#2b194d63":"#4a172444";g.fillRect(0,0,w,h);
 glow(cx,cy,Math.min(94,w*.38),homeScene?"#b0efbd58":realm==="rift"?"#b988ec56":"#fa88534a");
 const spread=Math.min(w*.21,49),heroX=cx-spread,mobX=cx+spread;
 if(homeScene){if(mode==="journal")sprite("clotharmor","idle_down",cx-35,cy,2);
 sprite(beast(),pulse&&motion==="bond"?"atk_down":"idle_down",cx,cy-3*pulse,2);
 }else{
 const dash=pulse&&motion==="slash"?pulse*spread:0,ani=dash?"atk_right":"idle_right";
 sprite("clotharmor",ani,heroX+dash,cy,1,false,dash?age:t);sprite(pet.blade?"bluesword":"sword1",ani,heroX+dash,cy,1,false,dash?age:t);
 const leap=motion==="skill"?pulse:0;
 sprite(beast(),leap?"atk_right":"idle_right",heroX-12+leap*(spread*2+8),cy+12-leap*16,1,false,leap?age:t);
 if(mode==="fight"){sprite(here().units[stage],lock?"atk_right":"idle_right",mobX,cy,1,true,lock?age:t);if(pulse)sprite("sparks","idle",motion==="guard"?heroX:mobX,cy-7,1,false,age)}
 else sprite("chest","idle_down",mobX,cy)
 }
 for(let i=0;i<18;i++){const x=(i*137+Math.sin(t*.4+i)*4+w)%w,y=(i*53+h-(t*(2+i%3))%h)%h;g.fillStyle=i%2?"#f6e59daa":"#c0f4d8ad";g.fillRect(Math.round(x),Math.round(y),1,1)}
 requestAnimationFrame(render)
}
c.onclick=e=>{if(mode!=="choose")return;const x=e.clientX/innerWidth,y=e.clientY/innerHeight;if(Math.abs(x-.5)<.23&&Math.abs(y-.47)<.17){home(pet.name+" 回应了你。兽技可造成 "+(3+lv())+" 点伤害。");animate("bond")}};
onresize=fit;
addEventListener("DOMContentLoaded",()=>Promise.all(Object.entries(DATA.images).map(([k,url])=>new Promise((ok,fail)=>{const im=new Image();im.onload=()=>{img[k]=im;ok()};im.onerror=fail;im.src=url}))).then(()=>{for(const [k,v] of Object.entries(DATA.scenes))maps[k]=bake(v);fit();if(studioURL)openStudio();else portrait();requestAnimationFrame(render)}).catch(()=>$("#hint").textContent="素材加载失败，请刷新重试。"));







