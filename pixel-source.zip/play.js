"use strict";
const $=s=>document.querySelector(s), canvas=$("canvas"), ctx=canvas.getContext("2d");
const images={}, foes=["goblin","skeleton","ogre"], names=["巡路地精","白骨剑士","山口巨魔"];
const route=[198,365,525], Y=128, key="shell-journey.watch.v1";
let stash={runs:0,blade:false,tonics:0};
try {Object.assign(stash,JSON.parse(localStorage.getItem(key))||{})} catch {}
let mode="camp", hero=112, enemy=0, hp=5, enemyHp=0, phase=0, timer=0, result="",damage=0,camera=0,clock=0;
const save=()=>{try{localStorage.setItem(key,JSON.stringify(stash))}catch{}};
const left=()=>[.48,.60,.36][enemy], span=()=>[.34,.27,.23][enemy];
function ui(title,note,action){
 $("#title").textContent=title;$("#note").textContent=note;$("#act").textContent=action;
 $("#act").disabled=["walk","strike","fallen","trek"].includes(mode);
 $(".meter").hidden=mode!=="duel";
 $("#stage").textContent=({camp:"村口营地",reward:"村道宝箱",end:"村口营地",trek:"山口补给站"})[mode]||("村道 · "+(enemy+1)+" / 3");
 $("#stats").textContent="体力 "+hp+" / 5　·　通关 "+stash.runs;
}
function camp(){
 mode="camp";enemy=0;hero=112;hp=5;camera=0;
 ui("准备出发",(stash.blade?"已佩蓝钢剑":"已佩铁剑")+" · 药剂 "+stash.tonics+" 瓶（体力耗尽时自动使用）","出发");
}
function walk(){
 mode="walk";enemyHp=enemy+2;ui(names[enemy],"沿村道前进中。","赶路中");
}
function duel(){
 mode="duel";phase=0;
 $(".zone").style.left=(left()*100)+"%";$(".zone").style.width=(span()*100)+"%";
 ui(names[enemy]+" · 体力 "+enemyHp,"白线进入金色区域时出剑。"+result,"出剑");
}
function act(){
 if(mode==="camp"){result="";walk()}
 else if(mode==="end"){camp()}
 else if(mode==="duel"){
  const p=1-Math.abs(1-phase), hit=p>=left()&&p<=left()+span();
  damage=hit?(stash.blade?3:2):0;mode="strike";timer=0;
  ui(hit?"命中":"被反击",hit?"剑锋击中守卫。":"挥剑落空，守卫趁机还击。","交锋中");
 }else if(mode==="reward"){
  stash.runs++;let prize;
  if(!stash.blade&&Math.random()<.45){stash.blade=true;prize="蓝钢剑 · 永久装备，命中伤害提升至 3。"}
  else{stash.tonics++;prize="回复药剂 · 下次体力耗尽时自动恢复 3 点。"}
  save();mode="end";ui("巡道完成",prize,"回营");
 }
}
function update(dt){
 clock+=dt;
 if(mode==="walk"||mode==="trek"){
  const dest=mode==="trek"?602:route[enemy]-17;
  hero=Math.min(dest,hero+dt*68);
  if(hero===dest){if(mode==="trek"){mode="reward";ui("抵达补给站","三名守卫已击败，打开宝箱抽取装备或药剂。","开箱")}else duel()}
 }else if(mode==="duel"){phase=(phase+dt*(1.13+enemy*.2))%2;$(".needle").style.left=((1-Math.abs(1-phase))*100)+"%"}
 else if(mode==="strike"&&(timer+=dt)>=.45){
  enemyHp-=damage;if(!damage)hp--;
  result=damage?"上次命中。":"上次落空。";
  if(hp<=0&&stash.tonics>0){stash.tonics--;hp=3;result="药剂生效。";save()}
  if(hp<=0){mode="end";ui("负伤撤退","补给队把你送回营地，休整后可再次出发。","回营")}
  else if(enemyHp<=0){mode="fallen";timer=0;ui("守卫倒下","前路已经打开。","行进中")}
  else duel();
 }else if(mode==="fallen"&&(timer+=dt)>=.55){
  if(enemy===2){mode="trek";ui("山口补给站","前往宝箱。","赶路中")}else{enemy++;result="";walk()}
 }
 camera=Math.max(0,Math.min(416,Math.round(hero-108)));
}
function sprite(id,anim,x,y,time,flip=false,rate=8){
 const d=DATA.sprites[id],a=d.animations[anim],f=Math.floor(time*rate)%a.length;
 ctx.save();ctx.translate(Math.round(x-camera)+(flip?16:0),y);if(flip)ctx.scale(-1,1);
 ctx.drawImage(images[id],f*d.width,a.row*d.height,d.width,d.height,d.offset_x,d.offset_y,d.width,d.height);ctx.restore();
}
function terrain(high){
 const map=DATA.map,img=images.tilesheet,cols=img.width/16;
 for(let y=0;y<11;y++)for(let x=camera>>4;x<Math.min(46,(camera>>4)+21);x++){
  for(const id of [].concat(map.data[y*46+x])){
   if(!id||upper.has(id)!==high)continue;
   const k=id-1;ctx.drawImage(img,(k%cols)*16,Math.floor(k/cols)*16,16,16,x*16-camera,y*16,16,16);
  }
 }
}
const upper=new Set(DATA.map.high);
function render(){
 ctx.clearRect(0,0,320,176);terrain(false);
 const attack=mode==="strike",ani=attack?"atk_right":["walk","trek"].includes(mode)?"walk_right":"idle_right",t=attack?timer:clock;
 sprite("chest","idle_down",620,Y,clock);
 sprite("clotharmor",ani,hero,Y,t,false,attack?11:8);sprite(stash.blade?"bluesword":"sword1",ani,hero,Y,t,false,attack?11:8);
 if(["walk","duel","strike"].includes(mode)){
  sprite(foes[enemy],attack&&!damage?"atk_right":"idle_right",route[enemy],Y,attack?timer:clock,true);
  if(attack&&timer>.12)sprite("sparks","idle",damage?route[enemy]:hero,Y-4,timer-.12,false,17);
 }else if(mode==="fallen")sprite("death","death",route[enemy],Y,timer,false,10);
 terrain(true);
}
$("#act").onclick=act;canvas.onpointerdown=()=>{if(mode==="duel")act()};
onkeydown=e=>{if(e.code==="Space"){e.preventDefault();if(!e.repeat&&!$("#act").disabled)act()}};
Promise.all(Object.entries(DATA.images).map(([k,url])=>new Promise((ok,fail)=>{const im=new Image();im.onload=()=>{images[k]=im;ok()};im.onerror=fail;im.src=url}))).then(()=>{
 ctx.imageSmoothingEnabled=false;camp();let last=performance.now();
 function frame(now){update(Math.min(.05,(now-last)/1000));last=now;render();requestAnimationFrame(frame)}requestAnimationFrame(frame)
}).catch(()=>$("#note").textContent="素材载入失败，请刷新重试。");
