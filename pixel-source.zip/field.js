"use strict";
const trailKey="shell-journey.moonmine.v1";
const trail=Object.assign({seed:crypto.getRandomValues(new Uint32Array(1))[0],edits:{},ore:0,gem:0,blocks:4,lamp:false,pick:false,visits:0,kills:0,taken:{},stats:{},ratings:[]},read(trailKey));
const persist=()=>{try{localStorage.setItem(trailKey,JSON.stringify(trail))}catch{}};
function mark(k){trail.stats[k]=(trail.stats[k]||0)+1}
function iconImage(id){const im=document.createElement("img");im.src=DATA.images[id];im.alt="";return im}
function button(label,icon,fn){const b=document.createElement("button");b.type="button";if(icon)b.append(iconImage(icon));b.append(label);b.onclick=fn;return b}
function journal(){
 mode="journal";$("main").dataset.mode="journal";$("#log").textContent="";
 const book=$("#journal");book.replaceChildren();
 const heading=document.createElement("h2");heading.textContent="我的行囊";book.append(heading);
 for(const [icon,line] of [["default_book","旅人手记　·　"+pet.name+" 同行"],["default_tool_steelpick",trail.pick?"已装备星纹镐 · 采掘距离提升":"钢镐 · 点击附近地层开采"],["default_mese_crystal","辉晶 "+trail.ore+"　月石 "+trail.gem+"　木台 "+trail.blocks],["default_chest_front","远征 "+trail.visits+" 次　驱散洞灵 "+trail.kills+" 只"]]){
 const row=document.createElement("p");row.append(iconImage(icon),line);book.append(row)}
  const portrait=document.createElement("canvas");portrait.width=80;portrait.height=35;portrait.style.cssText="position:static;width:128px;height:56px;image-rendering:pixelated;float:right";
 const ink=portrait.getContext("2d");for(const [id,x] of [["clotharmor",8],[beast(),48]]){const d=DATA.sprites[id],row=d.animations.idle_down.row;ink.drawImage(img[id],0,row*d.height,d.width,d.height,x,0,d.width,d.height)}
 book.insertBefore(portrait,heading);
 const stance=button(trail.guard?"守护 · 切换为探矿":"探矿 · 切换为守护","default_mese_crystal",()=>{trail.guard=!trail.guard;persist();journal()});book.append(stance);
 const desc=document.createElement("small");desc.textContent=trail.guard?" 洞灵每次远征的首次攻击由灵兽抵挡。":" 灵兽照亮附近藏矿。";book.append(desc);
  const credits=document.createElement("details"),summary=document.createElement("summary");summary.textContent="美术署名";credits.append(summary);
 for(const [name,url] of [["Little Workshop · BrowserQuest","https://github.com/mozilla/BrowserQuest"],["Minetest Game contributors · default","https://github.com/luanti-org/minetest_game/tree/master/mods/default"],["美术许可与逐项署名","https://github.com/luanti-org/minetest_game/blob/master/mods/default/license.txt"]]){const link=document.createElement("a");link.href=url;link.textContent=name;link.target="_blank";link.rel="noopener";credits.append(document.createElement("br"),link)}book.append(credits);
 const roleLine=document.createElement("p");roleLine.textContent=paths[trail.path].name+" · Rank "+rank()+" · "+paths[trail.path].summary;book.append(roleLine);const actions=[];
 if(new URLSearchParams(location.search).has("playtest"))actions.push(["记录试玩感受",feedback]);
 if(!trail.lamp)actions.push(["制矿灯 · 2 辉晶",()=>craft("lamp"),trail.ore<2]);
 if(!trail.pick)actions.push(["造星纹镐 · 1 月石",()=>craft("pick"),trail.gem<1]);
 actions.push(["探索矿谷",enterField],["秘境试炼",choose],["返回",()=>home()]);ui("我的行囊","旅人 · 羁绊 "+lv()+" 阶","",trail.lamp?"矿灯已装备。":"浅层采辉晶制矿灯。东方地底有三座遗匣，靠近后轻触开启。",actions)
}
function craft(kind){const cost=kind==="lamp"?2:1,stock=kind==="lamp"?"ore":"gem";if(trail[kind]||trail[stock]<cost)return;trail[stock]-=cost;trail[kind]=true;mark("craft");persist();journal()}
const TILE=16,COLS=100,ROWS=36;
let player,camX=0,camY=0,tool,pressed=new Set(),grounded=false,face=1,flash=0,fx=null,mineTarget=null,life=5,shield=false,hurtUntil=0,monster,petX,petY;
function surface(x){return 10+Math.round(Math.sin(x*.18)*1.4)+Math.round(Math.sin(x*.07)*1.2)}
function hash(x,y){let n=Math.imul(x+trail.seed,374761393)^Math.imul(y,668265263);return (Math.imul(n^(n>>>13),1274126177)>>>0)/4294967296}
function tile(x,y){
 if(x<0||x>=COLS||y>=ROWS)return "root";if(y<0)return "";
 const id=x+","+y;if(Object.hasOwn(trail.edits,id))return trail.edits[id];
 const h=surface(x),d=y-h;
 if(d<0)return "";if(y===ROWS-1)return "root";
 if((x===5||x===7)&&d===0)return "ore";
 if(x>9&&x<95&&d>2&&Math.abs(y-(h+5+Math.sin(x*.21)*2))<1.7)return "";
 if(d>4&&(hash(x,y)>.925||(x===5&&d===5)))return "gem";
 if(d>0&&hash(x,y)>.79)return "ore";return d===0?"grass":d<3?"soil":"rock"
}
function say(msg){$("#log").textContent=msg}
function labelStats(){$("#status").textContent="体力 "+life+"　辉晶 "+trail.ore+"　木台 "+trail.blocks}
function setupBar(){const bar=$("#fieldbar");bar.replaceChildren();
 for(const [id,label,icon] of [["mine","开采","default_tool_steelpick"],["build","搭台","default_wood"],["strike","挥剑","default_tool_steelsword"]]){
 const b=button(label,icon,()=>{tool=id;setupBar();if(id==="strike")strike();else say(id==="mine"?"点附近地层开采。":"点附近空处搭台，每次消耗一块。")});b.classList.toggle("active",id===tool);bar.append(b)}
 bar.append(button("整备","default_book",leave));
}
function pad(label,code,parent){const b=button(label,null,()=>{});b.setAttribute("aria-label",({left:"向左",right:"向右",jump:"跳跃"})[code]);b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);input(code,true)};b.onpointerup=b.onpointercancel=b.onlostpointercapture=()=>input(code,false);parent.append(b)}
function enterField(){mode="field";$("main").dataset.mode="field";$("#place").textContent="Moonfall Hollow · 月落矿谷";trail.visits++;persist();
 player={x:4.5*TILE,y:(surface(4)-1)*TILE,vy:0};petX=player.x-14;petY=player.y-20;grounded=false;camX=0;life=5;shield=!!trail.guard;tool="mine";hurtUntil=0;pressed.clear();fx=null;mineTarget=null;
 monster={x:17*TILE,y:(surface(17)-1)*TILE,hp:3,hit:0};setupBar();const pads=$("#pads");pads.replaceChildren();const l=document.createElement("div"),r=document.createElement("div");pads.append(l,r);pad("◀","left",l);pad("▶","right",l);pad("跃","jump",r);
 say("挖出脚边两块金色辉晶，可制矿灯。A/D 移动，空格跳，点地层采掘。");labelStats();camera()}
function leave(){mark("return");persist();pressed.clear();home("矿谷的改动已保存。打开行囊，用矿物制作装备。")}
function input(code,down){if(!down){pressed.delete(code);return}pressed.add(code);if(code==="jump"&&grounded){player.vy=-137;grounded=false;mark("jump")}}
addEventListener("keydown",e=>{if(mode!=="field")return;const code=({KeyA:"left",ArrowLeft:"left",KeyD:"right",ArrowRight:"right",KeyW:"jump",Space:"jump",ArrowUp:"jump"})[e.code];if(code){e.preventDefault();if(!e.repeat)input(code,true)}if(!e.repeat&&e.code==="KeyF")strike()});
addEventListener("keyup",e=>{const code=({KeyA:"left",ArrowLeft:"left",KeyD:"right",ArrowRight:"right",KeyW:"jump",Space:"jump",ArrowUp:"jump"})[e.code];if(code)input(code,false)});
addEventListener("blur",()=>pressed.clear());
function occupied(x,y){return [[-4,-13],[4,-13],[-4,-1],[4,-1]].some(([dx,dy])=>tile(Math.floor((x+dx)/16),Math.floor((y+dy)/16)))}
function moveAxis(dx,dy){const n=Math.ceil(Math.max(Math.abs(dx),Math.abs(dy)));for(let i=0;i<n;i++){const x=player.x+dx/n,y=player.y+dy/n;if(occupied(x,y)){if(dy){if(dy>0)grounded=true;player.vy=0}break}player.x=x;player.y=y}}
function camera(){camX=Math.max(0,Math.min(COLS*16-c.width,player.x-c.width*.42));camY=Math.max(0,Math.min(ROWS*16-c.height,player.y-c.height*.45))}
function strike(){if(mode!=="field"||t<flash)return;flash=t+.32;mark("swing");if(monster.hp>0&&Math.hypot(monster.x-player.x,monster.y-player.y)<42){monster.hp-=pet.blade?3:2;monster.hit=t+.35;monster.x+=face*12;if(monster.hp<=0){trail.kills++;trail.ore++;pet.xp++;store();persist();say("洞灵消散，获得辉晶。灵兽羁绊经验 +1。")}else say("剑与兽爪击中洞灵。");labelStats()}else say("挥剑。靠近洞灵时，灵兽会协同扑击。")}
function useAt(x,y){if(mode!=="field")return;if(tool==="strike"){strike();return}
 const id=x+","+y;mineTarget={x,y,until:t+.35};if(x<0||x>=COLS||y<0||y>=ROWS-1)return;
 if(Math.hypot(x*16+8-player.x,y*16+8-player.y+7)>(trail.pick?74:51)){say("距离太远，走近一点。");return}
 if(vaults.includes(x)&&vaultY(x)===y&&!trail.taken[x]){openVault(x);return}const block=tile(x,y);
 if(tool==="build"){
 if(block||!trail.blocks){say(block?"这里已有地块。":"木台用尽，开采泥土或岩石可补充。");return}
 if(Math.abs(player.x-(x*16+8))<13&&player.y>y*16&&player.y-13<(y+1)*16){say("脚下有人，换一个位置。");return}
 trail.edits[id]="plank";trail.blocks--;mark("build");say("木台已搭好，可以踩上去。")
 }else{
 if(!block||block==="root")return;trail.edits[id]="";mark("dig");fx={x:x*16+8,y:y*16+8,end:t+.35};
 if(block==="gem"){trail.gem++;say("找到月石！带回行囊可锻造星纹镐。")}else if(block==="ore"){trail.ore++;say(trail.ore>=2?"辉晶足够了，整备可制作矿灯。":"采到辉晶，再找一块就能造灯。")}else{trail.blocks++;say("获得建材。选「搭台」再点空处。")}
 }
 persist();labelStats()
}
c.addEventListener("pointerdown",e=>{if(mode!=="field")return;const rect=c.getBoundingClientRect();useAt(Math.floor(((e.clientX-rect.left)*c.width/rect.width+camX)/16),Math.floor(((e.clientY-rect.top)*c.height/rect.height+camY)/16))});
const textures={soil:"default_dirt",grass:"default_dirt",rock:"default_stone",ore:"default_stone",gem:"default_stone",plank:"default_wood",root:"default_stone"};
function drawTexture(id,x,y,w=16,h=16){g.drawImage(img[id],Math.round(x),Math.round(y),w,h)}
function woods(parallax,base,tint){
 const scroll=camX*parallax;
 for(let i=Math.floor(scroll/34)-2;i<(scroll+c.width)/34+2;i++){
  const wild=hash(i,88),x=Math.round(i*34+wild*12-scroll),height=Math.round(38+wild*35),y=Math.round(base+Math.sin(i*2.81)*7-camY*.32);
  if(wild>.72)g.drawImage(img.tilesheet,208,642,46,63,x-12,y-height*.25,Math.round(height*.55),height);
  else g.drawImage(img.tilesheet,193,162,62,78,x-15,y-height*.25,Math.round(height*.8),height);
 }
 g.fillStyle=tint;g.fillRect(0,0,c.width,c.height)
}
const vaults=[24,53,84];
function vaultY(x){return surface(x)+5+Math.round(Math.sin(x*.21)*2)}
function openVault(x){if(trail.taken[x])return;trail.taken[x]=true;trail.gem++;const prize=Math.random()<.5?"守夜药剂":"精炼辉晶";if(prize==="守夜药剂"){pet.herbs++;store()}else trail.ore+=3;mark("vault");persist();labelStats();say("打开遗匣：月石 +1，获得"+prize+"。")}function fieldFrame(dt){
 const dx=(+pressed.has("right")-+pressed.has("left"))*dt*66;if(dx)face=Math.sign(dx);
 moveAxis(dx,0);player.vy=Math.min(175,player.vy+340*dt);grounded=false;moveAxis(0,player.vy*dt);camera();
 let dist=Math.hypot(player.x-monster.x,player.y-monster.y);
 if(monster.hp>0){if(dist<95){monster.x+=Math.sign(player.x-monster.x)*dt*16;monster.y+=(player.y-7-monster.y)*dt*2}if(dist<13&&t>hurtUntil){if(shield){shield=false;say("灵兽替你挡下了一击。")}else life--;hurtUntil=t+1.2;labelStats();if(!life){persist();home("灵兽把你带出了矿谷，采到的矿物仍在行囊里。");return}}}
 const sky=g.createLinearGradient(0,0,0,c.height);sky.addColorStop(0,"#333757");sky.addColorStop(.65,"#c39086");sky.addColorStop(1,"#eac3a6");g.fillStyle=sky;g.fillRect(0,0,c.width,c.height);
  woods(.13,89,"#a39ab2aa");woods(.32,105,"#70698666");
 for(let x=Math.max(0,Math.floor(camX/16));x<Math.min(COLS,Math.ceil((camX+c.width)/16));x++)for(let y=Math.max(0,Math.floor(camY/16));y<Math.min(ROWS,Math.ceil((camY+c.height)/16));y++){
 const block=tile(x,y),px=Math.round(x*16-camX),py=Math.round(y*16-camY),depth=y-surface(x);
 if(!block){if(depth>=0){drawTexture("default_stone",px,py);g.fillStyle="#182034ce";g.fillRect(px,py,16,16)}continue}
 drawTexture(textures[block],px,py);if(block==="grass")drawTexture("default_grass_side",px,py);
 if(block==="ore"||block==="gem")drawTexture(block==="ore"?"default_mineral_mese":"default_mineral_diamond",px,py);
 if(!trail.guard&&(block==="ore"||block==="gem")&&Math.hypot(x*16+8-player.x,y*16+8-player.y)<60)glow(px+8,py+8,11,"#ffe79e51");if(depth>1){g.fillStyle="rgba(26,18,38,"+Math.min(.34,depth*.025)+")";g.fillRect(px,py,16,16)}
 }
  for(const x of vaults)if(!trail.taken[x]){const y=vaultY(x);sprite("chest","idle_down",x*16+8-camX,y*16+8-camY);glow(x*16+8-camX,y*16+8-camY,11,"#ffdc7c55")}
 const px=player.x-camX,py=player.y-camY;if(trail.lamp)glow(px,py-9,36,"#ffce7355");
 if(mineTarget&&mineTarget.until>t){g.strokeStyle="#ffe1a8";g.strokeRect(mineTarget.x*16-camX+.5,mineTarget.y*16-camY+.5,15,15)}
 petX+=(player.x-face*17-petX)*Math.min(1,dt*5);petY+=(player.y-19-petY)*Math.min(1,dt*5);
 const attacking=flash>t;const action=attacking?"atk_right":dx?"walk_right":"idle_right";
 sprite("clotharmor",action,px,py-7,1,face<0);if(tool==="strike"||attacking)sprite(pet.blade?"bluesword":"sword1",action,px,py-7,1,face<0);else drawTexture("default_tool_steelpick",px+(face>0?1:-11),py-14,11,11);
 sprite(beast(),attacking?"atk_right":"idle_right",petX-camX+(attacking?face*13:0),petY-camY+Math.sin(t*3)*2,1,face<0);
 if(monster.hp>0){sprite("spectre","walk_right",monster.x-camX,monster.y-camY-7,1,monster.x>player.x);if(monster.hit>t)sprite("sparks","idle",monster.x-camX,monster.y-camY-7)}
 if(fx&&fx.end>t)sprite("sparks","idle",fx.x-camX,fx.y-camY);
}

const testStart=performance.now(),baseline={...trail.stats};
function feedback(){
 const book=$("#journal");book.replaceChildren();const h=document.createElement("h2");h.textContent="试玩记录";book.append(h);
 const prompt=document.createElement("p");prompt.textContent="哪一步最难理解？你还想回来做什么？";book.append(prompt);
 const note=document.createElement("textarea");note.setAttribute("aria-label","试玩反馈");note.rows=3;note.style.width="100%";book.append(note);
 const offer=again=>{const actions={};for(const [k,v] of Object.entries(trail.stats))actions[k]=v-(baseline[k]||0);
 const info={version:"moonmine-1",seconds:Math.round((performance.now()-testStart)/1000),actions,wouldPlayAgain:again,note:note.value};
 const url=URL.createObjectURL(new Blob([JSON.stringify(info,null,2)],{type:"application/json"})),a=document.createElement("a");a.href=url;a.download="moonmine-playtest.json";a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);journal()};
 ui("试玩记录","","","选择后下载本次记录，文件由你自行分享。",[["愿意再玩",()=>offer(true)],["暂时不想",()=>offer(false)],["返回行囊",journal]])
}



let run;
function startRoof(){
 mode="roof";$("main").dataset.mode="roof";$("#place").textContent="夜渡 · 月瓦长街";$("#pads").replaceChildren(button("跃起","default_mese_crystal",roofJump),button("返回",null,()=>endRoof(false)));
 run={x:20,y:0,vy:0,ground:true,jumps:0,segments:[],crystals:[],loot:0,rescues:1,ready:false,done:false,lastSafe:20,speed:48,inv:0,best:0,buffer:0};
 const roll=crypto.getRandomValues(new Uint32Array(1))[0]%10000;
 let from=0,level=0;
 for(let i=0;i<12;i++){const length=i===0?112:70+Math.floor(hash(i,roll)*46);
 run.segments.push({from,to:from+length,level});
 run.crystals.push({x:from+length*.6,y:level-(i%3===1?25:11),taken:false});
 const gap=18+Math.floor(hash(i+8,roll)*11);from+=length+gap;level=[0,-5,2,-8,0,3][(i+1)%6]}
 mark("roofStart");persist();say("点画面或按空格起跑。再点跳跃，空中再点可借灵兽之力二段跳。");roofHud()
}
function roofHud(){$("#status").textContent="辉晶 "+run.loot+"　·　"+Math.floor(run.best/8)+" 步"}
function roofJump(){if(mode!=="roof"||run.done)return;if(!run.ready){run.ready=true;say("越过断檐，收集辉晶。");return}if(run.jumps>=2)return;run.vy=run.jumps===0?-113:-100;run.ground=false;run.jumps++;mark(run.jumps===2?"doubleJump":"roofJump")}
c.addEventListener("pointerdown",()=>{if(mode==="roof")roofJump()});
addEventListener("keydown",e=>{if(mode==="roof"&&["Space","ArrowUp","KeyW"].includes(e.code)){e.preventDefault();if(!e.repeat)roofJump()}});
function endRoof(win){if(mode!=="roof"||run.done)return;run.done=true;trail.ore+=run.loot;trail.best=Math.max(trail.best||0,Math.floor(run.best/8));if(win){trail.roofWins=(trail.roofWins||0)+1;trail.gem++;pet.xp+=2;store();mark("roofFinish")}mark("roofReturn");persist();home((win?"抵达灯塔，月石已收入行囊。":"踏瓦结束。")+"带回 "+run.loot+" 枚辉晶。")}
function roofFrame(dt){
 const w=c.width,h=c.height,floor=Math.round(h*.56);
 if(run.ready){const prev=run.y;run.x+=run.speed*dt;run.best=Math.max(run.best,run.x);run.vy+=285*dt;run.y+=run.vy*dt;
 const s=run.segments.find(s=>run.x>=s.from&&run.x<=s.to);
 if(s&&prev<=s.level+1&&run.y>=s.level&&run.vy>=0){run.y=s.level;run.vy=0;run.ground=true;run.jumps=0;if(run.x-s.from>4)run.lastSafe=s.from+5}else if(run.ground){run.ground=false;run.jumps=1}
 for(const v of run.crystals){if(!v.taken&&Math.hypot(v.x-run.x,v.y-(run.y-8))<13){v.taken=true;run.loot++;mark("roofCrystal")}}
 if(run.y>48){if(run.rescues-- >0){const spot=run.segments.find(s=>s.from<=run.lastSafe&&s.to>=run.lastSafe)||run.segments[0];run.x=run.lastSafe;run.y=spot.level;run.vy=0;run.jumps=0;run.ground=true;say(pet.name+"把你托回屋脊。下次失足将返回结算。")}else{endRoof(false);return}}
 if(run.x>=run.segments.at(-1).to-12){endRoof(true);return}roofHud()}
 const left=run.x-w*.29;
 const sky=g.createLinearGradient(0,0,0,h);sky.addColorStop(0,"#172342");sky.addColorStop(.55,"#756887");sky.addColorStop(1,"#d29b83");g.fillStyle=sky;g.fillRect(0,0,w,h);
 for(let i=0;i<24;i++){const sx=(hash(i,61)*w-left*.018+w*4)%w,sy=hash(i,62)*floor*.81;g.fillStyle=i%3?"#e4dcc39a":"#fff0bf";g.fillRect(Math.round(sx),Math.round(sy),1,1)}const moonX=w*.72-left*.025,moonY=h*.27;g.fillStyle="#f9dfab";g.beginPath();g.arc(moonX,moonY,Math.min(17,w*.09),0,Math.PI*2);g.fill();glow(moonX,moonY,28,"#ffe6b440");
 for(let i=Math.floor(left*.22/48)-1;i<(left*.22+w)/48+1;i++){const dh=37+hash(i,2)*21;g.fillStyle="#453f56";g.fillRect(Math.floor(i*48-left*.22)+3,floor+12,42,h);g.drawImage(img.tilesheet,52,161,112,144,Math.round(i*48-left*.22),Math.round(floor-dh+15),47,dh)}
 g.fillStyle="#6e6b924f";g.fillRect(0,0,w,h);
 for(const s of run.segments){const x=Math.round(s.from-left),y=floor+s.level,len=s.to-s.from;if(x>w||x+len<0)continue;
 g.save();g.beginPath();g.rect(x,y,len,h-y);g.clip();
 for(let col=0;col<len;col+=24){g.drawImage(img.tilesheet,102,41,22,22,x+col,y,24,10);for(let j=10;y+j<h;j+=20){drawTexture("default_brick",x+col,y+j,24,20)}}
 g.fillStyle="#352d458a";g.fillRect(x,y+10,len,h-y);g.fillStyle="#e4be8b";g.fillRect(x,y,len,1);
 for(let k=12;k<len;k+=37){g.drawImage(img.tilesheet,68,59,24,19,x+k,y+17,16,16);glow(x+k+8,y+24,12,"#ffc67b55")}
 g.restore()}
 for(const v of run.crystals)if(!v.taken&&v.x-left>-12&&v.x-left<w+12){const yy=floor+v.y+Math.sin(t*4+v.x)*2;drawTexture("default_mese_crystal",v.x-left-5,yy-5,10,10);glow(v.x-left,yy,9,"#ffda6c44")}
 const last=run.segments.at(-1);drawTexture("default_mese_post_light_side",last.to-left-14,floor+last.level-29,9,29);
 const px=Math.round(run.x-left);knight(px,floor+run.y,1,0,run.ready);sprite(beast(),run.jumps===2?"atk_right":"walk_right",px-15,floor+run.y-14+Math.sin(t*6)*2);
}



const paths=[
 {name:"Moonblade",weapon:"weapon_regular_sword",color:"#c7edee",summary:"主动技「月震」击退近敌，短暂护身。"},
 {name:"Windstring",weapon:"weapon_bow",color:"#dfc582",summary:"主动技「风羽」朝瞄准方向射出扇形箭雨。"},
 {name:"Starcaller",weapon:"weapon_knife",color:"#e2aaff",summary:"主动技「星落」召唤陨星打击多个敌人。"}
];
if(!Number.isInteger(trail.path)||!paths[trail.path]){trail.path=crypto.getRandomValues(new Uint32Array(1))[0]%paths.length;trail.vaultXP=0;persist()}
const rank=()=>demo?([1,2,4][stageEdit]):1+Math.min(5,Math.floor((trail.vaultXP||0)/3));
function knight(x,y,scale,angle,moving,roll=0,attacking=0){
 const look=currentLook();const id=look.skin+"_"+(moving?"run":"idle")+"_anim_f"+(Math.floor(t*(moving?10:5))%4),im=img[id],weapon=mode==="arena"&&journey?img[journey.items[journey.weapon]]:null;
 const flip=Math.cos(angle)<0;
 g.save();g.translate(Math.round(x),Math.round(y));g.scale(scale,scale);g.translate(0,-8);g.rotate(roll);g.scale(flip?-1:1,1);
 g.drawImage(im,-Math.floor(im.width/2),8-im.height);g.translate(4,2);g.rotate((flip?Math.PI-angle:angle)+.8+attacking);if(weapon)g.drawImage(weapon,-2,-weapon.height*.78);g.restore()
}
function portrait(){mode="portrait";$("main").dataset.mode=mode;$("#enterHero").onclick=()=>home(paths[trail.path].name+" · "+paths[trail.path].summary)}
function paintPortrait(){const w=c.width,h=c.height,cx=w/2,cy=h*.55;const sky=g.createRadialGradient(cx,cy,4,cx,cy,Math.max(w,h)*.66);sky.addColorStop(0,"#303041");sky.addColorStop(.45,"#1e202b");sky.addColorStop(1,"#0e1018");g.fillStyle=sky;g.fillRect(0,0,w,h);g.fillStyle="#11131b";g.beginPath();g.ellipse(cx,cy+1,19,4,0,0,Math.PI*2);g.fill();knight(cx,cy,Math.min(3.6,w/46),-.22,false)}
let battle,arKeys=new Set(),leftTouch=null,rightTouch=null;
const norm=(x,y)=>{const m=Math.hypot(x,y)||1;return [x/m,y/m]};
function launchChamber(){mode="arena";$("main").dataset.mode=mode;arKeys.clear();leftTouch=null;rightTouch=null;
 battle={x:c.width*.45,y:c.height*.56,hp:6,angle:0,cd:0,dash:0,dashCD:0,inv:1,swing:0,shots:[],bolts:[],fx:[],wave:1,fire:false,aim:null,dir:[1,0],ended:0,cover:themes[currentLook().map].cover.map(([x,y])=>({x:c.width*x,y:c.height*y,hp:3}))};loadChamber(0,0,0,0);
 const controls=$("#pads");controls.replaceChildren(button(skillNames[activePath()],null,castSkill),button("Dodge",null,dodge),button("Retreat",null,()=>endBattle(false)));
 say("WASD 移动 · 按住画面瞄准攻击 · 空格闪避 · E 技能。触屏左侧拖动，右侧按住攻击。");battleHud()
}
function battleHud(){$("#status").textContent="体力 "+battle.hp+"/6 · ("+journey.x+", "+journey.y+") · 已清 "+journey.clears}
function endBattle(win){if(mode!=="arena")return;if(demo){demo=false;arKeys.clear();leftTouch=null;rightTouch=null;openStudio();return}if(win){trail.vaultXP=(trail.vaultXP||0)+3;trail.ore+=2;pet.xp++;store();persist()}arKeys.clear();leftTouch=null;rightTouch=null;home(win?"地宫已清空 · 辉晶 +2，"+paths[activePath()].name+" 成长至 Rank "+rank()+"。":"已退出地宫。")}
function dodge(){if(mode!=="arena"||battle.dashCD>0)return;battle.dash=.2;battle.inv=.32;battle.dashCD=activePath()===0?.68:1.05;mark("dodge")}
function burst(x,y,color){battle.fx.push({x,y,color,ttl:.2})}
function attack(){
 const b=battle;if(b.cd>0)return;const id=journey.weapon;const target=b.aim||b.enemies.reduce((a,v)=>!a||Math.hypot(v.x-b.x,v.y-b.y)<Math.hypot(a.x-b.x,a.y-b.y)?v:a,null);
 if(target)b.angle=Math.atan2(target.y-b.y,target.x-b.x);
 const a=b.angle;b.swing=.23;b.cd=[.28,.35,.53][id]*100/currentLook().pace;mark("attack");
 if(id===0){for(const box of b.cover)if(Math.hypot(box.x-b.x,box.y-b.y)<25)box.hp--;for(const e of b.enemies){const dx=e.x-b.x,dy=e.y-b.y,dist=Math.hypot(dx,dy);if(dist<34&&(dist<12||(dx*Math.cos(a)+dy*Math.sin(a))/dist>-.12)){e.hp-=2+rank();e.hit=.16;burst(e.x,e.y,paths[id].color)}}}
 else for(const offset of id===1?[-.075,.075]:[0]){const dir=a+offset;b.shots.push({x:b.x,y:b.y-3,vx:Math.cos(dir)*125,vy:Math.sin(dir)*125,ttl:2,id})}
}
function point(e){return {x:e.clientX*c.width/innerWidth,y:e.clientY*c.height/innerHeight}}
c.addEventListener("pointerdown",e=>{if(mode!=="arena")return;const p=point(e);c.setPointerCapture(e.pointerId);
 if(e.pointerType!=="mouse"&&p.x<c.width*.5){leftTouch={id:e.pointerId,origin:p,p};return}
 rightTouch=e.pointerId;battle.aim=p;battle.fire=true;attack()});
c.addEventListener("pointermove",e=>{if(mode!=="arena")return;if(leftTouch?.id===e.pointerId)leftTouch.p=point(e);else if(rightTouch===e.pointerId||e.pointerType==="mouse")battle.aim=point(e)});
function release(e){if(leftTouch?.id===e.pointerId)leftTouch=null;if(rightTouch===e.pointerId){rightTouch=null;if(battle)battle.fire=false}}
for(const evt of ["pointerup","pointercancel","lostpointercapture"])c.addEventListener(evt,release);
addEventListener("keydown",e=>{if(mode!=="arena")return;if(["Space","ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(e.code))e.preventDefault();arKeys.add(e.code);if(e.code==="Space"&&!e.repeat)dodge();if(e.code==="KeyE"&&!e.repeat)castSkill()});
addEventListener("keyup",e=>arKeys.delete(e.code));addEventListener("blur",()=>{arKeys.clear();leftTouch=null;rightTouch=null;if(battle)battle.fire=false});
function arenaFrame(dt){
 const b=battle,w=c.width,h=c.height;updateSkill(dt);
 for(const k of ["cd","dash","dashCD","inv","swing"])b[k]=Math.max(0,b[k]-dt);
 let dx=+(arKeys.has("KeyD")||arKeys.has("ArrowRight"))-+(arKeys.has("KeyA")||arKeys.has("ArrowLeft")),dy=+(arKeys.has("KeyS")||arKeys.has("ArrowDown"))-+(arKeys.has("KeyW")||arKeys.has("ArrowUp"));
 if(leftTouch){dx+=leftTouch.p.x-leftTouch.origin.x;dy+=leftTouch.p.y-leftTouch.origin.y}
 const moving=Math.hypot(dx,dy)>.1;if(moving)b.dir=norm(dx,dy);
 if(moving||b.dash){const speed=b.dash?145:48;b.x+=b.dir[0]*dt*speed;b.y+=b.dir[1]*dt*speed}
 b.x=Math.max(9,Math.min(w-9,b.x));b.y=Math.max(22,Math.min(h-15,b.y));
 if(b.fire||arKeys.has("KeyJ"))attack();
 for(const box of b.cover){const dx=b.x-box.x,dy=b.y-box.y;if(Math.abs(dx)<10&&Math.abs(dy)<10){if(Math.abs(dx)>Math.abs(dy))b.x=box.x+(dx<0?-10:10);else b.y=box.y+(dy<0?-10:10)}}const hurt=()=>{if(!b.inv){b.hp--;b.inv=.8;burst(b.x,b.y,"#ff9183");battleHud()}};
 for(const e of b.enemies){if(e.hp<=0)continue;const [nx,ny]=norm(b.x-e.x,b.y-e.y),dist=Math.hypot(b.x-e.x,b.y-e.y),ranged=e.type!=="skelet";e.hit=Math.max(0,e.hit-dt);if(!e.hit&&(!ranged||dist>44)){const chase=(ranged?8:14)*currentLook().pressure/100;e.x+=nx*dt*chase;e.y+=ny*dt*chase}if(dist<9)hurt();if(ranged&&(e.cd-=dt)<=0){e.cd=(e.type==="big_demon"?1.45:2.25)*100/currentLook().pressure;for(const side of e.type==="big_demon"?[-.26,0,.26]:[0]){const a=Math.atan2(ny,nx)+side;b.bolts.push({x:e.x,y:e.y,vx:Math.cos(a)*44,vy:Math.sin(a)*44,ttl:4})}}}
 for(const s of b.shots){s.x+=s.vx*dt;s.y+=s.vy*dt;s.ttl-=dt;const cover=b.cover.find(o=>o.hp>0&&Math.hypot(o.x-s.x,o.y-s.y)<8);if(cover){cover.hp--;s.ttl=0;burst(cover.x,cover.y,"#ffe1aa");continue}const hit=b.enemies.find(e=>e.hp>0&&Math.hypot(e.x-s.x,e.y-s.y)<8);if(hit){s.ttl=0;for(const e of b.enemies)if(e===hit||(s.id===2&&Math.hypot(e.x-hit.x,e.y-hit.y)<28)){e.hp-=rank()+(s.id===2?2:0);e.hit=.14}burst(hit.x,hit.y,paths[s.id].color)}}
 for(const s of b.bolts){s.x+=s.vx*dt;s.y+=s.vy*dt;s.ttl-=dt;if(b.cover.some(o=>o.hp>0&&Math.hypot(o.x-s.x,o.y-s.y)<8)){s.ttl=0;continue}if(Math.hypot(s.x-b.x,s.y-b.y)<5){s.ttl=0;hurt()}}
 b.shots=b.shots.filter(s=>s.ttl>0);b.bolts=b.bolts.filter(s=>s.ttl>0);b.enemies=b.enemies.filter(e=>e.hp>0);
 if(b.hp<=0){endBattle(false);return}if(!b.enemies.length&&!journey.open)clearChamber();if(journey.open&&crossDoor())return;
 paintArenaFloor(g,w,h,journey.theme);drawDoors();
 for(const x of [12,w-18]){drawTexture("default_torch_on_floor",x,10,10,15);glow(x+5,20,30,"#f6ae6655")}
 b.cover=b.cover.filter(o=>o.hp>0);for(const o of b.cover)drawTexture("crate",o.x-8,o.y-9);for(const e of b.enemies){const im=img[e.type+"_run_anim_f"+(Math.floor(t*7)%4)];g.save();g.translate(Math.round(e.x),Math.round(e.y));g.scale(e.x>b.x?-1:1,1);g.globalAlpha=e.hit?.6:1;g.drawImage(im,-im.width/2,-im.height+5);g.restore()}
 g.save();g.globalAlpha=b.inv>0?.73:1;knight(b.x,b.y+4,1,b.angle,moving,b.dash?(1-b.dash/.2)*Math.PI*2:0,b.swing?Math.sin(b.swing/.23*Math.PI)*1.2:0);g.restore();
 if(b.aim&&b.fire){g.strokeStyle="#edd9a78a";g.lineWidth=1;g.beginPath();g.arc(b.aim.x,b.aim.y,4,0,Math.PI*2);g.stroke()}if(b.swing&&journey.weapon===0){g.strokeStyle="#d6fbec";g.lineWidth=2;g.beginPath();g.arc(b.x,b.y,22,b.angle-1.1,b.angle+1.1);g.stroke();g.lineWidth=1}
 for(const s of b.shots){g.strokeStyle=paths[s.id].color;g.lineWidth=s.id===2?3:1;g.beginPath();g.moveTo(s.x-s.vx*.055,s.y-s.vy*.055);g.lineTo(s.x,s.y);g.stroke()}g.lineWidth=1;
 for(const s of b.bolts){g.fillStyle="#fb9774";g.beginPath();g.arc(s.x,s.y,2,0,7);g.fill()}
 if(journey.ring>0){g.strokeStyle=paths[activePath()].color;g.beginPath();g.arc(b.x,b.y,10+(1-journey.ring/.4)*47,0,7);g.stroke()}for(const f of b.fx){f.ttl-=dt;sprite("sparks","idle",f.x,f.y,1,false,Math.max(0,.2-f.ttl)*3)}b.fx=b.fx.filter(f=>f.ttl>0)
}


const studioURL=new URLSearchParams(location.search).has("studio"),styleKey="shell-journey.atelier.v1";
const skins={knight_m:"灰盔骑士",knight_f:"赤羽骑士",dwarf_m:"山炉铁卫",elf_m:"林地弓手",elf_f:"夜巡游侠",lizard_m:"鳞甲猎人",wizzard_m:"灰袍术士",wizzard_f:"星纹术士",angel:"银翼使者"};
const arms={weapon_regular_sword:"长剑",weapon_katana:"弧刃",weapon_lavish_sword:"仪剑",weapon_double_axe:"双刃斧",weapon_bow:"木弓",weapon_bow_2:"角弓",weapon_green_magic_staff:"森杖",weapon_red_magic_staff:"余烬杖",weapon_knife:"短刃"};
const foes={skelet:"巡骨",imp:"小魔灵",wogol:"角魔",ogre:"石皮巨怪",big_zombie:"瘟疫傀儡",orc_shaman:"兽人祭司",big_demon:"深渊魔王"};
const themes={
 vault:{name:"藏灯地宫",floor:"floor_1",wall:"wall_mid",banner:"wall_banner_red",tint:"#24192b33",cover:[[.26,.44],[.69,.46],[.54,.76]]},
 grove:{name:"苔绿回廊",floor:"floor_5",wall:"default_wood",banner:"wall_banner_green",tint:"#26493255",cover:[[.30,.32],[.30,.65],[.68,.32],[.68,.65]]},
 ash:{name:"余烬王庭",floor:"default_obsidian_brick",wall:"default_brick",banner:"wall_banner_blue",tint:"#612b3c44",cover:[[.44,.30],[.53,.38],[.62,.46],[.35,.66]]}
};
const picks=[
 [["knight_m","weapon_regular_sword","vault","skelet"],["dwarf_m","weapon_double_axe","ash","ogre"],["knight_f","weapon_lavish_sword","ash","big_demon"]],
 [["knight_m","weapon_bow","grove","imp"],["elf_f","weapon_bow_2","grove","wogol"],["lizard_m","weapon_bow_2","vault","big_zombie"]],
 [["knight_m","weapon_green_magic_staff","vault","orc_shaman"],["wizzard_f","weapon_red_magic_staff","ash","wogol"],["angel","weapon_green_magic_staff","grove","big_demon"]]
];
const defaults=picks.map(route=>route.map(([skin,weapon,map,foe])=>({skin,weapon,map,foe,pace:100,pressure:100})));
function parseLook(data){return defaults.map((route,i)=>route.map((base,j)=>{const v=data?.[i]?.[j]||{},out={...base};for(const [key,options] of Object.entries({skin:skins,weapon:arms,map:themes,foe:foes}))if(typeof v[key]==="string"&&Object.hasOwn(options,v[key]))out[key]=v[key];for(const k of ["pace","pressure"])if(Number.isFinite(v[k]))out[k]=Math.min(140,Math.max(70,Math.round(v[k])));return out}))}
let liveLooks=parseLook(read(styleKey)),draft=structuredClone(liveLooks),routeEdit=trail.path,stageEdit=0,demo=false,batch=0,sample=null,notice="";
if(studioURL&&location.hash.startsWith("#looks=")){try{draft=parseLook(JSON.parse(decodeURIComponent(location.hash.slice(7))));notice="已载入分享方案，可预览或保存。"}catch{notice="分享内容无法读取，已载入本机方案。"}}
const activePath=()=>demo?routeEdit:trail.path;
function currentLook(){return demo?draft[routeEdit][stageEdit]:liveLooks[trail.path][rank()>=4?2:rank()>=2?1:0]}
function paintArenaFloor(ctx,w,h,map){
 const s=themes[map];for(let y=0;y<h;y+=16)for(let x=0;x<w;x+=16){const wall=y<16||y>=h-14;ctx.drawImage(img[wall?s.wall:s.floor],x,y,16,16)}
 ctx.fillStyle=s.tint;ctx.fillRect(0,0,w,h);for(let i=1;i<=3;i++)ctx.drawImage(img[s.banner],Math.round(w*i/4)-5,0,10,17)
}
function elm(tag,text,cls){const e=document.createElement(tag);if(text)e.textContent=text;if(cls)e.className=cls;return e}
function openStudio(){
 demo=false;mode="studio";$("main").dataset.mode=mode;const pane=$("#atelier");const scroll=pane.scrollTop;pane.hidden=false;pane.replaceChildren();const sheet=elm("div",null,"sheet");pane.append(sheet);sheet.append(elm("h1","The Atelier"),elm("p","逐条调整成长路线。选择只进入草稿，保存后会用于这个浏览器里的游戏。"));
 const selectors=elm("div",null,"commands");sheet.append(selectors);
 function selector(label,names,val,change){const wrap=elm("label",label+"　"),sel=elm("select");names.forEach((n,i)=>{const o=elm("option",n);o.value=i;o.selected=i===val;sel.append(o)});sel.onchange=()=>{change(+sel.value);batch=0;openStudio()};wrap.append(sel);selectors.append(wrap)}
 selector("路线",paths.map(v=>v.name),routeEdit,v=>routeEdit=v);selector("阶段",["初始 · Rank 1","进阶 · Rank 2","终阶 · Rank 4"],stageEdit,v=>stageEdit=v);
 const look=draft[routeEdit][stageEdit];sample=elm("canvas");sample.width=176;sample.height=68;sample.setAttribute("aria-label","所选角色、武器、敌人和地图动态预览");sheet.append(sample);
 function pool(title,key,options,ids,art){sheet.append(elm("h2",title));const row=elm("div",null,"pool");sheet.append(row);for(const id of [...new Set([look[key],...ids])]){const b=button(options[id].name||options[id],art(id),()=>{look[key]=id;notice="草稿已调整";openStudio()});b.setAttribute("aria-pressed",String(look[key]===id));row.append(b)}}
 const shortlist=([first,second,third],all)=>[first,second,third,...all].filter((v,i,a)=>a.indexOf(v)===i);
 const ordered=shortlist(picks[routeEdit].map(v=>v[0]),Object.keys(skins));const poolAt=(arr,n)=>Array.from({length:n},(_,i)=>arr[(batch*3+i)%arr.length]);
 pool("Character · 角色","skin",skins,poolAt(ordered,4),v=>v+"_idle_anim_f0");
 const armList=[["weapon_regular_sword","weapon_katana","weapon_double_axe","weapon_lavish_sword"],["weapon_bow","weapon_bow_2"],["weapon_green_magic_staff","weapon_red_magic_staff","weapon_knife"]][routeEdit];pool("Weapon · 武器","weapon",arms,armList,v=>v);
 pool("Realm · 地图","map",themes,Object.keys(themes),v=>themes[v].banner);
 pool("Encounter · 敌人","foe",foes,poolAt(Object.keys(foes),4),v=>v+"_run_anim_f0");
  const tune=elm("div",null,"commands");sheet.append(tune);for(const [id,title] of [["pace","攻击速度"],["pressure","敌人攻势"]]){const label=elm("label",title+"　"),out=elm("output",look[id]+"%"),slider=elm("input");slider.type="range";slider.min=70;slider.max=140;slider.step=5;slider.value=look[id];slider.style.width="100px";slider.setAttribute("aria-label",title);slider.oninput=()=>{look[id]=Number(slider.value);out.textContent=look[id]+"%"};label.append(slider,out);tune.append(label)}
 const row=elm("div",null,"commands");sheet.append(row);const status=elm("p",notice);status.setAttribute("role","status");
 row.append(button("下一批候选",null,()=>{batch++;notice="已切换本轮素材库的候选组合";openStudio()}),button("试玩此阶段",null,()=>{pane.hidden=true;demo=true;enterArena()}),button("保存到我的游戏",null,()=>{try{localStorage.setItem(styleKey,JSON.stringify(draft));liveLooks=structuredClone(draft);notice="已保存三条路线的全部阶段。"}catch{notice="本机存储不可用，可复制方案链接。"}openStudio()}),button("分享草稿",null,()=>{const u=new URL(location.href);u.hash="looks="+encodeURIComponent(JSON.stringify(draft));const box=elm("input");box.readOnly=true;box.value=u.href;sheet.append(box);box.select();navigator.clipboard?.writeText(u.href).then(()=>status.textContent="分享链接已复制。").catch(()=>status.textContent="可复制下方的方案链接。")}));
 sheet.append(status);const source=elm("a","美术来源 · 0x72 DungeonTileset II");source.href="https://github.com/ernestwwchin/myworld/tree/main/public/assets/vendor/0x72_dungeon";source.target="_blank";source.rel="noopener";sheet.append(source);pane.scrollTop=scroll;
}
function paintSample(){if(!sample)return;const ctx=sample.getContext("2d"),v=draft[routeEdit][stageEdit];ctx.imageSmoothingEnabled=false;paintArenaFloor(ctx,176,68,v.map);
 for(const [x,y] of themes[v.map].cover)ctx.drawImage(img.crate,Math.round(x*176)-4,Math.round(y*68)-4,9,9);
 const f=Math.floor(t*6)%4,hero=img[v.skin+"_idle_anim_f"+f],enemy=img[v.foe+"_run_anim_f"+f];ctx.drawImage(hero,43-hero.width/2,52-hero.height);ctx.drawImage(img[v.weapon],48,32,9,21);ctx.save();ctx.translate(124,51);ctx.scale(-1,1);ctx.drawImage(enemy,-enemy.width/2,-enemy.height);ctx.restore()}



const skillNames=["月震","风羽","星落"];
let journey;
function enterArena(){
 const items=demo?[draft[routeEdit][stageEdit].weapon]:[...new Set([liveLooks[0][0].weapon,liveLooks[1][0].weapon,liveLooks[2][0].weapon])];
 if(demo){const allowed=[["weapon_regular_sword","weapon_lavish_sword","weapon_katana","weapon_double_axe"],["weapon_bow","weapon_bow_2"],["weapon_green_magic_staff","weapon_red_magic_staff","weapon_knife"]];const itemsAll=["weapon_regular_sword","weapon_bow","weapon_green_magic_staff"];itemsAll[routeEdit]=items[0];beginJourney(itemsAll,allowed.findIndex(a=>a.includes(items[0])));return}
 mode="armory";$("main").dataset.mode="home";$("#log").textContent="";
 ui("Vault entrance","","挑一件武器","长刃近战，弓射双箭，法杖溅射。成长路线决定主动技，武器由你决定。",[]);
 const nav=$("nav");nav.replaceChildren(...items.map((v,i)=>button(arms[v],v,()=>beginJourney(items,i))),button("返回",null,()=>home()));
}
function beginJourney(items,weapon){
 journey={seed:crypto.getRandomValues(new Uint32Array(1))[0],items,weapon,x:0,y:0,visited:new Set(),cleared:new Set(),clears:0,skill:0,ring:0,open:false};
 launchChamber();battleHud()
}
function chamberHash(x,y,salt=0){let h=Math.imul(x^journey.seed,73856093)^Math.imul(y,19349663)^Math.imul(salt+1,83492791);h=Math.imul(h^(h>>>16),2246822507);return (h^(h>>>13))>>>0}
const exits=[[1,0],[-1,0],[0,-1],[0,1]];
function hasDoor(x,y,dx,dy){return dx!==0||x===0||chamberHash(x,Math.min(y,y+dy),7)%3!==0}
function loadChamber(x,y,dx,dy){
 const j=journey,b=battle,key=x+","+y,h=chamberHash(x,y),d=Math.abs(x)+Math.abs(y);
 j.x=x;j.y=y;j.visited.add(key);j.open=j.cleared.has(key);j.theme=!d?currentLook().map:Object.keys(themes)[h%3];j.kind=!d?"entrance":d%5===0?"guardian":h%7===0?"spring":"hall";
 const w=c.width,H=c.height;b.x=dx>0?20:dx<0?w-20:w*.5;b.y=dy>0?32:dy<0?H-27:H*.54;
 b.cover=themes[j.theme].cover.map(([u,v])=>({x:(h%2?1-u:u)*w,y:v*H,hp:3}));b.shots=[];b.bolts=[];b.fx=[];b.fire=false;b.aim=null;b.inv=1;b.dash=0;
 const units=j.kind==="entrance"?["skelet","skelet"]:j.kind==="guardian"?["big_demon","orc_shaman"]: [currentLook().foe,["skelet","imp","ogre"][h%3],...(d>2?["orc_shaman"]:[])];
 b.enemies=j.open||j.kind==="spring"?[]:units.map((type,i)=>{const spots=[[.20,.30],[.81,.35],[.50,.74],[.78,.72]].filter(([a,v])=>Math.hypot(a*w-b.x,v*H-b.y)>22);const [a,v]=spots[(i+(h%spots.length))%spots.length];return {type,x:a*w,y:v*H,hp:(type==="big_demon"?9:3)+Math.min(7,Math.floor(d/4)),cd:2+i,hit:0}});
 if(j.kind==="spring"&&!j.open){b.hp=Math.min(6,b.hp+2);j.open=true;j.cleared.add(key)}
 $("#place").textContent=themes[j.theme].name+" · "+({entrance:"入口",guardian:"守卫厅",spring:"泉室",hall:"回廊"})[j.kind];say(j.open?"门已开启。走进亮门探索相邻房间。":"清除守卫，点亮出口。");battleHud()
}
function clearChamber(){const j=journey;j.open=true;j.cleared.add(j.x+","+j.y);j.clears++;
 if(!demo){trail.ore+=j.kind==="guardian"?3:1;trail.vaultXP=(trail.vaultXP||0)+1;if(j.kind==="guardian")trail.gem++;persist()}
 say("守卫已清。走入青色门洞选择下一间，也可以原路返回。");battleHud()
}
function crossDoor(){const b=battle,j=journey,w=c.width,h=c.height;for(const [dx,dy] of exits){if(!hasDoor(j.x,j.y,dx,dy))continue;const at=dx?(Math.abs(b.y-h*.5)<13&&(dx>0?b.x>=w-10:b.x<=10)):(Math.abs(b.x-w*.5)<13&&(dy>0?b.y>=h-16:b.y<=23));if(at){loadChamber(j.x+dx,j.y+dy,dx,dy);return true}}return false}
function drawDoors(){const j=journey,w=c.width,h=c.height;for(const [dx,dy] of exits){if(!hasDoor(j.x,j.y,dx,dy))continue;const x=dx===1?w-4:dx===-1?4:w*.5,y=dy===1?h-7:dy===-1?12:h*.5;g.save();g.translate(x,y);if(dx)g.rotate(Math.PI/2);g.drawImage(img.wall_mid,-16,-5,32,10);g.fillStyle="#161524";g.fillRect(-10,-5,20,10);g.restore();g.fillStyle=j.open?"#81d9b4":"#985b5c";g.fillRect(Math.round(x-(dx?3:12)),Math.round(y-(dy?3:12)),dx?6:24,dy?6:24);if(j.open)glow(x,y,12,"#77ffba61")}
 const ox=w-18,oy=25;for(let i=-2;i<=2;i++)for(let k=-2;k<=2;k++){const id=(j.x+i)+","+(j.y+k);if(!j.visited.has(id)&&Math.abs(i)+Math.abs(k)!==1)continue;if(!j.visited.has(id)&&!hasDoor(j.x,j.y,i,k))continue;g.fillStyle=!i&&!k?"#ffe0a0":j.cleared.has(id)?"#99c5b5":"#666879";g.fillRect(ox+i*4,oy+k*4,3,3)}}
function castSkill(){if(mode!=="arena"||journey.skill>0)return;const b=battle,k=activePath();journey.skill=[4,4,6][k];journey.ring=.4;
 if(k===0){b.inv=1;for(const e of b.enemies){const dx=e.x-b.x,dy=e.y-b.y;if(Math.hypot(dx,dy)>58)continue;const [nx,ny]=norm(dx,dy);e.hp-=4;e.x=Math.max(8,Math.min(c.width-8,e.x+nx*14));e.y=Math.max(20,Math.min(c.height-14,e.y+ny*14));burst(e.x,e.y,paths[k].color)}}
 else if(k===1){const target=b.aim||b.enemies[0],a=target?Math.atan2(target.y-b.y,target.x-b.x):b.angle;for(let i=-3;i<=3;i++)b.shots.push({x:b.x,y:b.y,vx:Math.cos(a+i*.12)*145,vy:Math.sin(a+i*.12)*145,ttl:2,id:1})}
 else for(const e of b.enemies.slice(0,3)){e.hp-=4;e.hit=.3;burst(e.x,e.y,paths[k].color)}
}
function updateSkill(dt){journey.skill=Math.max(0,journey.skill-dt);journey.ring=Math.max(0,journey.ring-dt);const btn=$("#pads button");if(btn){const txt=skillNames[activePath()]+(journey.skill>0?" "+Math.ceil(journey.skill)+"s":" · E");if(btn.textContent!==txt)btn.textContent=txt;btn.disabled=journey.skill>0}}

