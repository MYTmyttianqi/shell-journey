"use strict";
const {createServer}=require("node:http");
const {readFile}=require("node:fs/promises");
const path=require("node:path");
const P=require("./profiles.js");
const port=Number(process.env.PORT||8787);
const model=process.env.SHELL_AI_MODEL;
const endpoint=process.env.SHELL_AI_URL;
const key=process.env.SHELL_AI_KEY||process.env.OPENAI_API_KEY;
const allowedOrigin=process.env.SHELL_APP_ORIGIN;
const files=new Map([
  ["/","index.html"],["/index.html","index.html"],["/style.css","style.css"],
  ["/art.js","art.js"],["/profiles.js","profiles.js"],["/game.js","game.js"],
  ["/shape-weights.js","shape-weights.js"],["/shape-model.js","shape-model.js"],
  ["/presentation.js","presentation.js"],["/care.js","care.js"],
  ...["grotto","mineral","lacquer","ink-gorge"].map(name=>["/assets/"+name+".webp","assets/"+name+".webp"])
]);
const mime={".html":"text/html; charset=UTF-8",".js":"text/javascript; charset=UTF-8",".css":"text/css; charset=UTF-8",".webp":"image/webp"};
let busy=false;
function json(response,status,value){
  response.writeHead(status,{"Content-Type":"application/json; charset=UTF-8","Cache-Control":"no-store"});
  response.end(JSON.stringify(value));
}
async function parse(request){
  let body="";
  for await(const chunk of request) {
    body+=chunk;
    if(body.length>2048)throw new Error("请求太长");
  }
  const {seed,interactions}=JSON.parse(body);
  if(!Number.isInteger(seed)||seed<0||seed>0xffffffff||
    !Array.isArray(interactions)||interactions.length!==2||
    interactions.some(event=>!["tap","warm"].includes(event)))throw new Error("互动记录无效");
  return {seed,interactions};
}
async function profile({seed,interactions}) {
  const egg=P.initial(seed);
  const choices={rig:P.rigs,mood:P.moods,tone:P.tones,shape:[0,1,2],eggForm:[0,1,2],...P.limits};
  const headers={"Content-Type":"application/json"};
  if(key)headers.Authorization="Bearer "+key;
  const r=await fetch(endpoint,{headers,method:"POST",signal:AbortSignal.timeout(14000),
    body:JSON.stringify({model,messages:[
      {role:"system",content:"Generate one virtual folklore pet and its next shell form from exactly two player gestures. Return a JSON object containing exactly these keys. Use one option per enumerated list. body, head, tail, posture and markAt are continuous numeric ranges. warm suggests a shy, low shell rig, while tap suggests a curious, tall tail rig. Give different seeds visibly different body proportions, shape, posture and mark placement even with identical gestures. shape 0 is the benchmark, 1 flatter/wider, 2 higher/more curled. eggForm should differ from the supplied original egg. The renderer preserves the inherited mark independently. Options and bounds: "+JSON.stringify(choices)},
      {role:"user",content:JSON.stringify({seed,interactions,originalEggForm:egg.eggForm})}
    ],response_format:{type:"json_object"}})});
  if(!r.ok)throw new Error("模型调用失败");
  const output=await r.json();
  const p=P.validate(JSON.parse(output.choices[0].message.content),egg);
  if(p.eggForm===egg.eggForm)p.eggForm=(p.eggForm+1)%3;
  return p;
}
const app=createServer(async(req,res)=>{
  const pathname=new URL(req.url,"http://localhost").pathname;
  if(allowedOrigin&&req.headers.origin===allowedOrigin) {
    res.setHeader("Access-Control-Allow-Origin",allowedOrigin);
    res.setHeader("Vary","Origin");
    res.setHeader("Access-Control-Allow-Methods","GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers","Content-Type");
    if(req.method==="OPTIONS"){res.writeHead(204);res.end();return;}
  }
  if(pathname==="/api/status"&&req.method==="GET")return json(res,200,{available:Boolean(endpoint&&model)});
  if(pathname==="/api/generate"&&req.method==="POST") {
    const localOrigin="http://127.0.0.1:"+port;
    if(req.headers.origin&&req.headers.origin!==localOrigin&&req.headers.origin!==allowedOrigin)
      return json(res,403,{error:"来源无效"});
    if(!endpoint||!model)return json(res,503,{error:"模型尚未配置"});
    if(busy)return json(res,429,{error:"已有生成请求"});
    busy=true;
    try {
      let input;
      try {input=await parse(req);} catch {return json(res,400,{error:"互动记录无效"});}
      return json(res,200,await profile(input));
    } catch {
      return json(res,502,{error:"生成未完成"});
    } finally {busy=false;}
  }
  const file=files.get(pathname);
  if(req.method!=="GET"||!file)return json(res,404,{error:"未找到"});
  try {
    const body=await readFile(path.join(__dirname,file));
    res.writeHead(200,{"Content-Type":mime[path.extname(file)]});
    res.end(body);
  } catch {json(res,500,{error:"资源无法打开"});}
});
app.listen(port,"127.0.0.1",()=>console.log("壳旅 http://127.0.0.1:"+port+"/"));

