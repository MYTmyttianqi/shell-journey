"use strict";
const ShellProfiles = (() => {
  const tones = ["lacquer","ember","moss","jade"];
  const clamp = (v,min,max) => Math.max(min,Math.min(max,v));
  const limits={body:[.79,1.24],head:[.77,1.22],tail:[.78,1.25],posture:[-.68,.68],markAt:[-.8,.8]};
  const rigs=["shell","tail"];
  const moods=["shy","curious"];
  const benchmarks={
    shell:{rig:"shell",tone:"lacquer",mood:"shy",body:1.04,head:.94,tail:1,posture:0,markAt:0,shape:0,eggForm:0,mark:0},
    tail:{rig:"tail",tone:"moss",mood:"curious",body:1.02,head:.98,tail:1,posture:0,markAt:-.65,shape:0,eggForm:2,mark:2}
  };
  function rng(seed) {
    let a=seed>>>0;
    return () => {
      a=(a+0x6d2b79f5)>>>0;
      let t=Math.imul(a^(a>>>15),a|1);
      t^=t+Math.imul(t^(t>>>7),t|61);
      return ((t^(t>>>14))>>>0)/4294967296;
    };
  }
  const initial = seed => {
    const next=rng(seed);
    return {...benchmarks.shell,mark:Math.floor(next()*3),eggForm:Math.floor(next()*3)};
  };
  function simulate(seed,inputs) {
    const tap=inputs.filter(x=>x==="tap").length;
    const warm=inputs.length-tap;
    const rig=tap>warm?"tail":"shell";
    const next=rng((seed^((tap+1)*0x16aa9d17))>>>0);
    const range=(a,b)=>a+next()*(b-a);
    return {...initial(seed),rig,mood:tap>=warm?"curious":"shy",
      tone:tones[(rig==="tail"?2:0)+Math.floor(next()*2)],
      body:range(.81,1.23),head:range(.78,1.21),tail:range(.79,1.24),
      posture:range(-.64,.64),markAt:range(-.8,.8),shape:Math.floor(next()*3),
      eggForm:(initial(seed).eggForm+1+Math.floor(next()*2))%3};
  }
  function validate(value,initialEgg) {
    if(!value||typeof value!=="object"||Array.isArray(value)) throw new Error("缺少造型参数");
    if(!rigs.includes(value.rig)||!moods.includes(value.mood)||!tones.includes(value.tone)) throw new Error("造型分类无效");
    const result={rig:value.rig,tone:value.tone,mood:value.mood,mark:initialEgg.mark};
    for(const [key,[min,max]] of Object.entries(limits)) {
      if(!Number.isFinite(value[key])) throw new Error("造型数值无效");
      result[key]=clamp(value[key],min,max);
    }
    for(const key of ["shape","eggForm"]) {
      if(!Number.isInteger(value[key])||value[key]<0||value[key]>2) throw new Error("造型选项无效");
      result[key]=value[key];
    }
    return result;
  }
  return {initial,simulate,validate,benchmarks,limits,tones,rigs,moods,rng};
})();
if(typeof module!=="undefined") module.exports=ShellProfiles;
