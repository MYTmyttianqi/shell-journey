"use strict";
window.ShellArt = (() => {
  const ground = 281;
  const w = 640, h = 360;
  const images = Object.fromEntries(["grotto","mineral","lacquer"].map(name => {
    const img = new Image();
    img.src = "assets/" + name + ".webp";
    return [name,img];
  }));
  const ready = img => img.complete && img.naturalWidth > 0;
  const clamp = (x,a=0,b=1) => Math.max(a,Math.min(b,x));
  const step = (a,b,x) => { const t = clamp((x-a)/(b-a)); return t*t*(3-2*t); };
  const lerp = (a,b,t) => a+(b-a)*t;
  const paths = new Map();
  function path(d) {
    if (!paths.has(d)) {
      if (paths.size > 450) paths.clear();
      paths.set(d,new Path2D(d));
    }
    return paths.get(d);
  }
  function at(c,x,y,paint,sx=1,sy=sx,angle=0) {
    c.save(); c.translate(x,y); c.rotate(angle); c.scale(sx,sy); paint(); c.restore();
  }
  function gradient(c,x,y,x2,y2,colors) {
    const g = c.createLinearGradient(x,y,x2,y2);
    colors.forEach((v,i) => g.addColorStop(i/(colors.length-1),v));
    return g;
  }
  function fill(c,d,style,edge,width=1) {
    const p = path(d);
    c.fillStyle=style; c.fill(p);
    if (edge) { c.lineWidth=width; c.strokeStyle=edge; c.lineJoin="round"; c.stroke(p); }
  }
  function line(c,d,style,width=1) {
    c.strokeStyle=style; c.lineWidth=width; c.lineCap="round"; c.lineJoin="round"; c.stroke(path(d));
  }
  function oval(c,x,y,rx,ry,style) {
    c.beginPath(); c.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),0,0,Math.PI*2); c.fillStyle=style; c.fill();
  }
  function glow(c,x,y,r,color,sy=1) {
    at(c,x,y,() => {
      const g=c.createRadialGradient(0,0,0,0,0,r);
      g.addColorStop(0,color); g.addColorStop(1,"transparent");
      oval(c,0,0,r,r,g);
    },1,sy);
  }
  function surface(c,d,colors,top,bottom,{edge="#2e271b",tex="mineral",alpha=.23,mono=false}={}) {
    if (mono) { fill(c,d,"#e3e3e3"); return; }
    fill(c,d,gradient(c,-26,top,19,bottom,colors),edge,1.05);
    const img=images[tex];
    if (!ready(img)) return;
    c.save(); c.clip(path(d)); c.globalAlpha*=alpha; c.globalCompositeOperation="soft-light";
    c.drawImage(img,-105,top-23,230,bottom-top+46); c.restore();
  }
  const comma="M0 -5 C-4 -6 -7 -2 -6 1 C-5 4 -1 4 1 2 C0 6 -3 8 -5 9 C0 9 5 4 5 0 C5 -3 3 -5 0 -5Z";
  function mark(c,x,y,scale,design,angle=0) {
    at(c,x,y,() => {
      const color=["#f2c36b","#e8a268","#edd487"][design%3];
      c.shadowColor="#f1aa3d80"; c.shadowBlur=3;
      fill(c,comma,color);
      at(c,13,-4,() => fill(c,comma,color),.86,.86,.1);
      if (design%3===2) oval(c,8,9,1.35,1.15,color);
      if (design%3===1) oval(c,-8,7,1,1,color);
    },scale,scale,angle);
  }

  const shellShapes=[
    "M-82 -14 Q-60 -25 -41 -47 C-20 -71 14 -78 39 -62 Q58 -49 60 -32 Q47 -39 37 -27 Q14 -10 -15 -17 Q-49 -19 -82 -14Z",
    "M-91 -15 C-69 -20 -47 -39 -31 -46 Q7 -61 34 -52 C51 -46 58 -38 63 -25 Q45 -32 34 -23 Q-7 -11 -30 -15 Q-64 -17 -91 -15Z",
    "M-67 -11 Q-62 -32 -43 -53 Q-26 -81 -2 -85 C22 -88 48 -64 60 -40 Q64 -31 60 -26 Q43 -30 27 -21 Q-2 -12 -22 -18Z"
  ];
  const tails=[
    "M14 -43 C5 -40 -3 -27 -16 -19 C-33 -6 -59 -4 -69 -13 C-80 -23 -66 -47 -54 -48 Q-47 -49 -44 -40 Q-38 -51 -48 -57 C-66 -66 -90 -43 -91 -24 C-95 0 -77 9 -52 6 C-24 5 -8 -10 11 -20Z",
    "M14 -39 C-2 -36 -9 -21 -28 -13 Q-53 2 -70 -5 Q-86 -14 -72 -32 Q-67 -37 -60 -36 C-68 -50 -90 -37 -94 -21 Q-101 3 -75 8 Q-33 9 -14 -5 L17 -19Z",
    "M14 -47 C-6 -44 -11 -22 -30 -13 Q-53 -1 -64 -15 C-75 -30 -61 -56 -47 -60 Q-37 -62 -37 -53 C-29 -64 -39 -75 -51 -72 C-71 -67 -87 -45 -86 -22 Q-85 5 -60 7 Q-20 5 6 -18Z"
  ];
  const tones={
    lacquer:["#aa7852","#6a4230","#3c2822","#1d2219"],
    ember:["#c49161","#845037","#4b2b25","#28211a"],
    moss:["#b9b485","#82845d","#515e3d","#303725"],
    jade:["#c8c6a1","#929379","#566e61","#3c4b3c"]
  };
  const skin=["#d8bc88","#9a8057","#5c583e","#36352b"];
  const darkSkin=["#a39468","#71684b","#45412f"];
  const bodyTail="M-17 -43 Q-21 -53 -5 -63 Q5 -66 9 -77 L17 -89 Q31 -94 35 -76 Q31 -64 25 -55 C28 -39 22 -28 11 -24 C0 -18 -16 -27 -17 -43Z";
  const bodyShell="M-51 -28 Q-46 -43 -14 -43 Q22 -45 40 -37 Q57 -31 48 -19 Q21 -13 -7 -15 Q-36 -13 -55 -14Z";
  function foot(c,x,y,dx,dy,near,mono,thin=false) {
    const a=thin?5:7;
    const d="M"+(x-a)+" "+y+" Q"+(x-9)+" "+(y+9)+" "+(dx-a)+" "+(dy-6)
      +" Q"+(dx-a-3)+" "+(dy-1)+" "+(dx-a)+" "+dy
      +" Q"+(dx+1)+" "+(dy+1.3)+" "+(dx+4)+" "+(dy-.8)
      +" Q"+(dx+8)+" "+(dy+.3)+" "+(dx+10)+" "+(dy-1)
      +" Q"+(dx+13)+" "+(dy-3)+" "+(dx+5)+" "+(dy-6)
      +" L"+(x+a)+" "+(y-2)+"Z";
    surface(c,d,near?skin:darkSkin,y,dy,{mono,alpha:.13});
    if (!mono && near) line(c,"M"+(dx+4)+" "+(dy-4)+" l2 3","#d7b785",.9);
  }
  function gait(q,phase,amplitude,lift) {
    const u=((q+phase)%1+1)%1;
    if (u<.63) return [lerp(amplitude,-amplitude,u/.63),0];
    const v=(u-.63)/.37;
    return [lerp(-amplitude,amplitude,step(0,1,v)),-Math.sin(v*Math.PI)*lift];
  }
  function feelers(c,reach=0,mono=false,t=0) {
    const tip=8*Math.sin(t*3);
    line(c,"M0 0 Q"+(16+reach)+" -17 "+(3+reach*1.8)+" "+(-34+reach*1.3+tip*.3),
      mono?"#e3e3e3":"#c8a573",mono?2.7:1.7);
    line(c,"M2 3 Q"+(22+reach)+" -5 "+(22+reach*1.6)+" "+(-23+reach*.87-tip*.3),
      mono?"#e3e3e3":"#dbb07d",mono?2.5:1.55);
  }
  function eye(c,x,y,r=4,closed=false) {
    if (closed) { line(c,"M"+(x-r)+" "+y+" q"+r+" 3 "+(r*2)+" -1","#423120",1.4); return; }
    oval(c,x,y,r,r*.86,"#2a2418"); oval(c,x+.6,y-.6,r*.57,r*.63,"#a7864e");
    oval(c,x+1.05,y-.25,r*.39,r*.58,"#161612"); oval(c,x+1.1,y-r*.42,r*.22,r*.2,"#f6e7ac");
  }
  function reed(c) {
    line(c,"M-35 3 L37 -27","#282217",6);
    line(c,"M-35 2 L36 -27","#bba269",2.8);
    fill(c,"M29 -24 Q42 -35 51 -32 Q45 -22 34 -22Z",gradient(c,37,-35,38,-20,["#b7b2a0","#6d7770","#424b43"]),"#4b402d");
    line(c,"M27 -25 l4 6 M30 -27 l4 6 M33 -28 l3 5","#d0ac78",1.1);
  }
  function pet(c,x,y,p,anim={},opts={}) {
    const {mono=false,only=null,equipped=false,scale=1,facing=1}=opts;
    const {t=0,walk=0,strength=0,dip=0,reach=0,air=0,tailAir=0,crouch=0,startle=0,lean=0,sleep=false}=anim;
    const isShell=p.rig==="shell";
    const tone=tones[p.tone]??tones.lacquer;
    const show=layer=>!only||only===layer;
    const b=p.body, head=p.head, posture=p.posture;
    const hop=isShell?0:air;
    const bob=Math.sin(walk*Math.PI*4)*(isShell?1.0:2.5)*strength + Math.sin(t*2.7)*1.05;
    const bodyY=(isShell?dip*8:dip*16)+bob+crouch*9+startle*8-hop;
    const tailY=bodyY*.35-tailAir*.74-Math.sin(walk*Math.PI*2-1.1)*4*strength+crouch*7;
    const tailYScale=.9+posture*.12;
    const muzzle=isShell ? 46-startle*14+reach*7+lean*8 : 17-startle*7+lean*8+reach*5+dip*19;
    const headY=isShell ? -34+bodyY+dip*1.7 : -81+bodyY-(b-1)*24+posture*7+dip*43;
    const headShape=isShell
      ?"M-14 -5 Q-6 -17 9 -13 Q19 -10 24 -2 Q32 0 29 7 Q24 13 10 10 Q-5 13 -14 5Z"
      :"M-13 3 Q-17 -5 -10 -12 Q-4 -18 7 -15 Q17 -14 24 -7 L36 -1 Q32 7 20 4 Q10 14 0 13Z";
    at(c,x,y,() => {
      if (!mono&&!only) glow(c,0,1,86,"#0b0c08af",.15);
      at(c,0,0,() => {
        if (show("tail")) {
          if (isShell) {
            at(c,-40,bodyY*.6,() => surface(c,"M0 -22 C-21 -32 -36 -17 -40 -12 Q-24 -12 -13 -16 L4 -14Z",darkSkin,-32,-12,{mono}),p.tail,1);
          } else {
            at(c,2,tailY,() => {
              surface(c,tails[p.shape],tone,-68,8,{mono,alpha:.42});
              if (!mono) line(c,"M-76 -18 Q-73 -36 -61 -44 M-62 -6 Q-44 -3 -24 -13","#e6c98660",1.8);
            },p.tail,tailYScale);
          }
        }
        [0,1,2,3].forEach(i=>{
          if (!show("limb"+i)||(!isShell&&i>1)) return;
          const front=i%2===1;
          const near=isShell?i>1:front;
          const anchor=(isShell?(front?30:-39):(front?9:-9))*b;
          const [dx,dy]=gait(walk,[.43,.02,.01,.43][i],isShell?11:17,isShell?4.5:12);
          const toe=anchor+(near?5:-5)+dx*strength;
          foot(c,anchor,(isShell?-26:-39)*b+bodyY,toe,dy*strength-hop,near,mono,!isShell);
        });
        if (show("body")) {
          at(c,isShell?0:dip*8,bodyY,() => {
            surface(c,isShell?bodyShell:bodyTail,isShell?skin:tone,isShell?-45:-94,-16,{mono,alpha:.35});
            if (!isShell&&!mono) {
              surface(c,"M15 -78 Q28 -80 25 -65 Q22 -54 17 -43 Q12 -34 2 -34 Q15 -52 11 -62Z",skin,-82,-34);
              line(c,"M-11 -49 Q-3 -53 4 -50 M-10 -42 Q-5 -45 1 -44","#d7c49098",1.5);
            }
          },isShell?b:1+(b-1)*.68,isShell?1:b*(1-dip*.34));
          if(!isShell&&dip>.03) {
            const n=step(.03,.2,dip);
            const endX=muzzle-3, endY=headY+3;
            c.save(); c.globalAlpha*=n;
            line(c,"M16 "+(-47+bodyY)+" Q"+(endX-19)+" "+(endY-9)+" "+endX+" "+endY,
              mono?"#e3e3e3":tone[1],14);
            if(!mono)line(c,"M21 "+(-45+bodyY)+" Q"+(endX-15)+" "+(endY-4)+" "+(endX+3)+" "+(endY+3),skin[1],5);
            c.restore();
          }
        }
        if (show("head")) {
          at(c,muzzle,headY,() => {
            if (!isShell) {
              surface(c,"M-4 -9 Q-22 -29 -35 -24 Q-23 -21 -18 -12 Q-34 -25 -45 -14 Q-25 -15 -13 -3Z",tone,-28,4,{mono});
              surface(c,"M-9 6 Q-18 11 -18 23 Q-10 21 -4 14 Q-4 25 0 28 Q5 19 9 10Z",tone,5,28,{mono});
            }
            surface(c,headShape,skin,-17,14,{mono,alpha:.2});
            if (!mono) {
              if (isShell) fill(c,"M-7 0 Q3 -10 14 -8 L21 -3 Q9 -4 4 4Z","#ac7952");
              eye(c,isShell?12:14,-3,isShell?3.45:4.1,sleep||Math.sin(t*1.11)>.993||dip>.86);
              line(c,isShell?"M22 6 q4 1 6 -1":"M23 1 l10 -1","#644a35",1);
            }
            if (isShell) at(c,22,1,() => feelers(c,reach*19,mono,t));
          },head,head,(isShell?.03:.09)*dip+(isShell?.04:.36)*reach-startle*.12);
        }
        if (isShell&&show("shell")) {
          at(c,-startle*4,bodyY,() => {
            surface(c,shellShapes[p.shape],tone,-79,-14,{mono,tex:"lacquer",alpha:.55});
            if (!mono) {
              line(c,"M-72 -17 Q-48 -25 -41 -38 M-37 -46 Q-17 -65 3 -66 M37 -56 Q48 -48 52 -41","#d4a77f90",1.4);
              line(c,"M-44 -22 Q-20 -30 -7 -28 Q17 -23 31 -30","#e0b78b72",1.4);
              oval(c,-34,-29,9,2.15,"#7d805246"); oval(c,-46,-21,7,1.55,"#9d936445");
            }
          },b,.91+posture*.19);
        }
        if (!mono&&show("mark")) {
          if (isShell) mark(c,p.markAt*12*b-startle*4,-45+bodyY-posture*6,.84,p.mark,-.18);
          else if (p.markAt>.33) mark(c,muzzle+5,headY-10,.48,p.mark,-.1);
          else if (p.markAt<-.33) {
            const [mx,my]=[[-83,-22],[-89,-17],[-77,-23]][p.shape];
            at(c,2,tailY,() => clipDraw(c,tails[p.shape],()=>mark(c,mx,my,.46,p.mark,.83)),p.tail,tailYScale);
          }
          else mark(c,-1+dip*8+p.markAt*5,-50*b+bodyY,.57,p.mark,-.30);
        }
        if (equipped && show("gear")) {
          const saddleY=isShell?[-49,-42,-56][p.shape]:-52;
          at(c,isShell?-2:5,saddleY+bodyY,()=> {
            if(!mono)line(c,"M-9 -3 Q-4 5 2 8","#926b42",3.9);
            reed(c);
          },.95,.95,isShell?-.34:-.6);
        }
      },facing,1);
    },scale,scale);
  }

  function eggShape(form) {
    const width=[42,49,37][form];
    return "M0 -109 C"+(-width*.49)+" -111 "+(-width-4)+" -68 "+(-width)+" -37 C"+(-width+1)+" -13 -20 0 0 0 C26 0 "+width+" -13 "+width+" -38 C"+(width+4)+" -63 "+(width*.54)+" -110 0 -109Z";
  }
  function shellSurface(c,p,molt) {
    const d=eggShape(p.eggForm);
    const art=tones[p.tone];
    const skinColor=["#bac0a1","#837e63","#4f5946","#323728"];
    surface(c,d,molt>.02?[molt>.66?art[0]:"#d8bb84",art[1],art[2],"#242820"]:skinColor,-105,0,{alpha:.64});
    c.save(); c.clip(path(d));
    if (molt>0) {
      c.globalAlpha*=molt;
      fill(c,"M-40 -74 L-26 -98 -8 -105 3 -99 16 -96 21 -80 11 -68 -6 -74 -14 -63 -36 -67Z",
        gradient(c,-31,-97,15,-63,["#e1c08b","#947252","#5d6051"]),"#bd9e72");
      fill(c,"M38 -50 L27 -41 32 -28 18 -15 28 -1 57 -2Z","#403323","#ad8359");
      line(c,"M-44 -43 L-29 -53 -27 -44 -17 -42 M20 -88 l-3 13 10 11 2 12 M-21 -13 l-8 3 -12 -4","#f0c38892",1.05);
    } else {
      line(c,"M-25 -76 Q-19 -91 -8 -96 M-36 -42 Q-34 -55 -29 -61","#e6d9ae65",1.4);
    }
    c.restore();
    c.save();c.clip(path(d));
    for(let i=0;i<46;i++) {
      const x=(i*37%81)-40, y=(i*59%103)-103;
      oval(c,x,y,i%6===0?2.2:1, i%7===0?1.35:.55, i%2?"#f3ce9a4d":"#30271d4d");
    }
    c.restore();
    mark(c,-7,-66,1.06,p.mark,-.13);
  }
  const topClip="M-79 -130 H80 V-51 L39 -55 26 -49 15 -56 2 -49 -11 -54 -21 -48 -33 -54 -79 -46Z";
  const baseClip="M-79 -46 L-33 -54 -21 -48 -11 -54 2 -49 15 -56 26 -49 39 -55 80 -51 V21 H-79Z";
  function clipDraw(c,d,draw){c.save();c.clip(path(d));draw();c.restore();}
  function shellDebris(c,x,p,progress) {
    const fall=step(.39,.91,progress);
    if (fall<.002) return;
    at(c,x,ground,() => {
      c.globalAlpha*=step(.4,.66,progress);
      surface(c,"M-36 -2 l10 -6 8 3 -2 5Z",tones[p.tone],-9,0);
      surface(c,"M25 -1 l13 -9 6 5 -4 5Z",tones[p.tone],-10,0);
      surface(c,"M-54 -1 l7 -5 2 4 -3 2Z",tones[p.tone],-6,0);
    });
  }
  function egg(c,x,p,t,molt=0,crack=0) {
    const hatch=crack>0;
    const thrust=step(.18,.50,crack);
    const open=step(.12,.34,crack);
    const tilt=Math.sin(t*7)*.014+Math.sin(crack*47)*.045*(1-thrust);
    glow(c,x,ground+1,54,"#090a07e0",.26);
    if (molt>.04) glow(c,x-7,ground-52,61,"#dc8f3440");
    if (hatch) {
      if (p.rig==="shell") {
        at(c,x+25,ground-50,() => feelers(c,9+open*9,false,t),open+.02,open+.02,-.28);
      } else {
        const tailOut=step(.016,.37,crack);
        at(c,x-6,ground-11,() => surface(c,tails[p.shape],tones[p.tone],-64,8),
          tailOut*.65+.003,tailOut*.62+.003,-.14*(1-tailOut));
      }
      const show=step(.29,.55,crack);
      if(show>0) {
        c.save();
        c.globalAlpha*=show;
        const out=step(.28,.96,crack);
        pet(c,x+lerp(13,104,out),ground,p,{t,walk:out*1.55,strength:Math.sin(out*Math.PI)},{scale:lerp(.78,1,show)});
        c.restore();
      }
    }
    at(c,x,ground,() => {
      if (!hatch) {
        shellSurface(c,p,molt);
        return;
      }
      const draw=()=>shellSurface(c,p,1);
      c.save();
      c.globalAlpha*=1-step(.62,.91,crack);
      clipDraw(c,baseClip,draw);
      line(c,"M-41 -50 L-33 -54 -21 -48 -11 -54 2 -49 15 -56 26 -49 40 -55","#efd09c",1.2);
      c.restore();
      const fall=step(.52,.91,crack);
      c.save(); c.globalAlpha*=1-step(.81,.96,crack);
      const carry=step(.28,.60,crack)*(1-fall);
      at(c,carry*25-fall*57,-open*2-thrust*24+fall*75,() => clipDraw(c,topClip,draw),1-fall*.17,1-fall*.17,carry*.18-fall*.93);
      c.restore();
    },1,1,tilt);
    if(hatch) shellDebris(c,x,p,crack);
  }

  function leaf(c,x,y,scale=1,angle=0) {
    at(c,x,y,() => {
      fill(c,"M0 0 Q-8 -17 3 -20 Q14 -22 19 -31 Q23 -10 12 -4 Q6 0 0 0Z",gradient(c,-3,-26,15,0,["#b5a65f","#849451","#4c613b"]),"#4f5c3a",.85);
      line(c,"M-4 5 Q4 -7 15 -22 M5 -11 l-1 -6 M8 -14 l6 -1 M2 -7 l-1 -5","#c2ba7b",.77);
      oval(c,8,-14,1.35,1,"#dadab3a3");
    },scale,scale,angle);
  }
  function bowl(c,herb) {
    at(c,493,ground,() => {
      glow(c,1,-2,34,"#100e09b0",.23);
      fill(c,"M-28 -16 Q-27 -1 -15 0 Q2 4 18 0 Q28 -2 29 -16Z",gradient(c,-11,-20,5,4,["#b98052","#815039","#452d21"]),"#3e2c1a");
      oval(c,0,-16,29,8,"#af7950"); oval(c,0,-16,24,5.8,"#352820");
      line(c,"M-24 -14 Q-8 -6 13 -10 M20 -11 l3 -1","#e5ac777f",1.1);
      if(herb>.05) leaf(c,0,-14,.57*herb,.67);
    });
  }
  function lamp(c,x,y,on=true) {
    if(on) {glow(c,x,y-27,115,"#f9a33d39",.76);glow(c,x,y-4,57,"#f2b35c4b",.31);glow(c,x,y-26,29,"#ff9a438f");}
    at(c,x,y,() => {
      const bronze=gradient(c,-8,-58,15,0,["#b3925d","#756044","#a47d49","#554031"]);
      oval(c,0,0,19,4.2,"#19150e");
      fill(c,"M-16 -1 L-14 -5 -7 -8 -5 -13 -10 -16 L10 -16 5 -13 7 -7 15 -5 17 -1Z",bronze,"#40301e");
      fill(c,"M-12 -16 -13 -33 13 -33 12 -16Z",on?"#a96734c0":"#333024","#725038",2);
      if(on) fill(c,"M0 -18 Q-9 -22 1 -33 Q1 -27 5 -23 Q7 -18 0 -18Z","#ffd98d");
      line(c,"M-13 -31 L-11 -17 M13 -31 L11 -17","#cfaa70",1.7);
      fill(c,"M-19 -33 Q-15 -39 -3 -41 Q-6 -46 0 -47 Q6 -46 3 -41 Q14 -38 19 -33Z",bronze,"#493522");
      line(c,"M-16 -33 L15 -33","#d5ad72",1.1);
    });
  }
  function room(c,t,{herb=0,lampOn=false,lampPlaced=false,trip=0}={}) {
    c.fillStyle=gradient(c,0,0,0,h,["#323526","#272c21","#1c1d15"]);
    c.fillRect(0,0,w,h);
    const img=images.grotto;
    if(ready(img)) c.drawImage(img,0,0,w,h);
    c.fillStyle="#23281b20";c.fillRect(0,0,w,h);
    glow(c,272,ground-74,132,"#e8c9801e");
    at(c,105,ground-1,() => {
      glow(c,0,2,67,"#0a0d07ac",.19);
      surface(c,"M-61 0 Q-44 -13 -28 -11 Q-18 -26 4 -22 Q23 -25 34 -16 Q50 -17 58 -3 Q34 3 -61 0Z",
        ["#9c9560","#696e42","#3f4830","#242e20"],-27,2,{alpha:.64});
      line(c,"M-43 -4 Q-30 -13 -13 -10 Q-3 -19 13 -17 M13 -13 q13 -2 27 5","#b4a77779");
    });
    bowl(c,herb);
    if(lampPlaced) lamp(c,565,ground,lampOn);
    for(let i=0;i<14;i++) {
      const x=(i*97+30+Math.sin(t*.45+i)*13)%638;
      const y=36+(i*137%230)+Math.cos(t*.55+i*.8)*12;
      const a=.17+(.5+.5*Math.sin(t*1.1+i*2))*.39;
      oval(c,x,y,i%5===0?1.55:.82,1,"rgba(243,215,139,"+a+")");
    }
    if(trip>0) glow(c,638,ground-46,90,"#ead18b33");
    const g=c.createRadialGradient(300,180,155,322,173,363);
    g.addColorStop(0,"transparent");g.addColorStop(1,"#070b07a9");
    c.fillStyle=g;c.fillRect(0,0,w,h);
  }
  return {w,h,ground,room,egg,pet,lamp,leaf,mark,step,clamp,lerp,ready:Promise.all(Object.values(images).map(img=>img.decode().catch(()=>{})))};
})();
