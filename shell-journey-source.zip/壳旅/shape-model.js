"use strict";
const ShellShapeModel = (() => {
  const weights=typeof module==="undefined"?ShellShapeWeights:require("./shape-weights.js");
  const profiles=typeof module==="undefined"?ShellProfiles:require("./profiles.js");
  const keys=["body","head","tail","posture","markAt"];
  const sequences=["warm/warm","warm/tap","tap/warm","tap/tap"];

  function sample(seed,gestures,excludedShape){
    const gesture=sequences.indexOf(gestures.join("/"));
    if(gesture<0)throw new Error("造型模型需要两次有效互动");
    const initial=profiles.initial(seed);
    const next=profiles.rng((seed^Math.imul(gesture+1,0x3c6ef35f))>>>0);
    const candidates=weights.filter(component=>component.rig+"-"+component.shape!==excludedShape);
    const total=candidates.reduce((sum,component)=>sum+component.gestureCounts[gesture],0);
    let draw=next()*total;
    const component=candidates.find(value=>(draw-=value.gestureCounts[gesture])<0);
    const noise=keys.map(()=>{
      const radius=Math.sqrt(-2*Math.log(Math.max(Number.EPSILON,next())));
      return radius*Math.cos(2*Math.PI*next());
    });
    const geometry=Object.fromEntries(keys.map((key,i)=>[
      key,component.factor[i].reduce((sum,loading,j)=>sum+loading*noise[j],component.center[i])
    ]));
    const tones=component.rig==="shell"?["lacquer","ember"]:["moss","jade"];
    return profiles.validate({
      ...geometry,rig:component.rig,shape:component.shape,tone:tones[Math.floor(next()*tones.length)],
      mood:gestures[1]==="tap"?"curious":"shy",
      eggForm:(initial.eggForm+1+component.shape%2)%3
    },initial);
  }
  return {sample};
})();
if(typeof module!=="undefined")module.exports=ShellShapeModel;
