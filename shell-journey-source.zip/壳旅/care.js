"use strict";
const ShellCare = (() => {
  const P=typeof module==="undefined"?ShellProfiles:require("./profiles.js");
  const Model=typeof module==="undefined"?ShellShapeModel:require("./shape-model.js");
  const sequences=[["warm","warm"],["warm","tap"],["tap","warm"],["tap","tap"]];
  const key="shell-journey.care.v1", matureBond=22, maxAway=8*60*60*1000;
  const clamp=(value,min=0,max=100)=>Math.max(min,Math.min(max,value));
  const shapeNames={shell:["弧瓦","长檐","隆脊"],tail:["玉钩","横钩","挑月"]};
  const families={shell:"背壳兽",tail:"摆尾兽"};
  const suffixes=["苔","露","砾","眠","泠","栖","岚","微","穗","霜","棠","禾"];
  const prefixes={shell:["藏","伏","砚","眠","玄","岫"],tail:["游","轻","拾","松","望","野"]};
  const shapeKey=pet=>pet.rig+"-"+pet.shape;

  function roll(seed,previous){
    const next=P.rng(seed^0x9e3779b9);
    const egg=P.initial(seed);
    const sampleSeed=Math.floor(next()*0x100000000);
    const sample=Model.sample(sampleSeed,sequences[Math.floor(next()*sequences.length)],previous);
    return P.validate({...sample,eggForm:(egg.eggForm+1+sample.shape%2)%3},egg);
  }
  function name(seed,pet){
    const values=prefixes[pet.rig];
    const next=P.rng(seed^0x77159203);
    return values[Math.floor(next()*values.length)]+suffixes[Math.floor(next()*suffixes.length)];
  }
  const create=(seed,t=Date.now())=>({
    v:1,seed,pet:null,satiety:0,energy:0,bond:0,trips:0,lamp:false,restUntil:0,updatedAt:t,archive:[],resources:0,draws:0
  });
  function finishHatch(save){
    if(save.pet)return false;
    save.pet=roll(save.seed,save.archive.at(-1)?.shape);
    save.satiety=59; save.energy=88;
    return true;
  }
  const change=(save,{satiety=0,energy=0,bond=0})=>{
    save.satiety=clamp(save.satiety+satiety);
    save.energy=clamp(save.energy+energy);
    save.bond=clamp(save.bond+bond,0,9999);
  };
  function settle(save,t){
    const end=Math.max(save.updatedAt,t);
    if(!save.pet){save.updatedAt=end;return false;}
    const nap=save.restUntil;
    const start=nap?Math.max(save.updatedAt,Math.min(nap,end)):save.updatedAt;
    const hours=clamp(end-start,0,maxAway)/3600000;
    if(hours>0) {
      save.satiety=Math.max(18,save.satiety-hours*6);
      save.energy=Math.max(16,save.energy-hours*4);
    }
    save.updatedAt=end;
    if(!nap||end<nap)return false;
    save.restUntil=0;
    change(save,{energy:57,bond:2});
    return true;
  }
  const canExplore=save=>save.bond>=8&&save.satiety>=54&&save.energy>=45;
  const canAdopt=save=>save.bond>=matureBond&&save.trips>=2;
  const growth=save=>save.bond>=matureBond?"长成":save.bond>=8?"少兽":"幼兽";

  function recommend(save){
    if(!save.pet)return "hatch";
    if(save.restUntil)return "";
    if(save.satiety<68)return "feed";
    if(save.energy<58)return "rest";
    return "play";
  }
  function nextEgg(save,seed,t){
    const next=create(seed,t);
    next.lamp=save.lamp;
    next.resources=save.resources;next.draws=save.draws;
    next.archive=[...save.archive,{name:name(save.seed,save.pet),shape:shapeKey(save.pet)}].slice(-24);
    return next;
  }
  function decode(text){
    if(!text)return null;
    try{
      const data=JSON.parse(text);
      if(data?.v!==1||!Number.isInteger(data.seed)||data.seed<0||data.seed>0xffffffff)return null;
      const clean=create(data.seed,Number.isFinite(data.updatedAt)?Math.min(data.updatedAt,Date.now()):Date.now());
      if(data.pet)clean.pet=P.validate(data.pet,P.initial(data.seed));
      for(const field of ["satiety","energy","bond","trips","restUntil","resources","draws"]){
        if(Number.isFinite(data[field]))clean[field]=clamp(data[field],0,field==="restUntil"?Date.now()+20000:["bond","trips","resources","draws"].includes(field)?9999:100);
      }
      clean.lamp=data.lamp===true;
      if(Array.isArray(data.archive))clean.archive=data.archive.filter(p=>typeof p?.name==="string"&&/^(shell|tail)-[012]$/.test(p.shape))
        .slice(-24).map(p=>({name:p.name.slice(0,12),shape:p.shape}));
      return clean;
    }catch{return null;}
  }
  return {key,create,decode,roll,name,finishHatch,settle,change,recommend,canExplore,canAdopt,nextEgg,growth,shapeNames,families,matureBond};
})();
if(typeof module!=="undefined")module.exports=ShellCare;

