"use strict";
const ShellRunner=(()=>{
  function start(t){return {start:t,last:t,y:0,vy:0,items:[],next:0,coins:0,hits:0,finished:false};}
  function jump(r){if(r.y===0&&!r.finished)r.vy=370;}
  function step(r,t){
    const dt=Math.min(.05,Math.max(0,t-r.last));r.last=t;
    r.y=Math.max(0,r.y+r.vy*dt);r.vy-=850*dt;if(!r.y)r.vy=0;
    if(t-r.start>r.next&&t-r.start<19){r.items.push({x:680,type:Math.random()<.48?"rock":"dew",collected:false});r.next+=1.12;}
    for(const item of r.items){
      item.x-=175*dt;
      if(!item.collected&&Math.abs(item.x-140)<26){
        if(item.type==="dew"&&r.y<105){item.collected=true;r.coins++;}
        if(item.type==="rock"&&r.y<32){item.collected=true;r.hits++;}
      }
    }
    r.items=r.items.filter(item=>item.x>-50);
    if(t-r.start>=20||r.hits>=3)r.finished=true;
  }
  function draw(c,r,pet,t){
    ShellArt.room(c,t,{trip:1});
    c.fillStyle="#12180f99";c.fillRect(0,300,640,60);
    for(const item of r.items){
      if(item.collected)continue;
      if(item.type==="rock"){
        c.fillStyle="#82775a";c.beginPath();c.moveTo(item.x-22,281);c.lineTo(item.x-10,253);c.lineTo(item.x+13,251);c.lineTo(item.x+24,281);c.fill();
      }else{
        c.fillStyle="#efc77c";c.beginPath();c.arc(item.x,256,7,0,Math.PI*2);c.fill();
      }
    }
    ShellArt.pet(c,140,281-r.y,pet,{t,walk:(t-r.start)*1.5,strength:1,air:0},{scale:.9});
    c.fillStyle="#f0dfba";c.font="16px sans-serif";
    c.fillText("石露 "+r.coins+"   碰撞 "+r.hits+"/3",18,32);
    c.textAlign="right";c.fillText("剩余 "+Math.max(0,Math.ceil(20-(t-r.start)))+" 秒",620,32);c.textAlign="left";
  }
  return {start,jump,step,draw};
})();

