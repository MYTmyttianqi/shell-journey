"use strict";
(() => {
  const scene=document.querySelector(".device-scene");
  const device=scene.querySelector(".device");
  const footer=document.querySelector(".footer");
  const backdrop=footer.querySelector(".footer-image");
  const heading=document.querySelector("#phase");
  const reduced=matchMedia("(prefers-reduced-motion: reduce)");
  const pointer=matchMedia("(hover: hover) and (pointer: fine)");
  const rest={x:0,y:0};
  let current=rest,target=rest,deviceFrame=0,footerFrame=0;

  function reflect(){
    const next={
      x:current.x+(target.x-current.x)*.12,
      y:current.y+(target.y-current.y)*.12
    };
    const moving=Math.hypot(next.x-target.x,next.y-target.y)>.0007;
    current=moving?next:target;
    const {x,y}=current;
    for(const [name,value] of Object.entries({
      gx:(50+x*66)+"%",gy:(35+y*52)+"%",
      rx:(y*-2.0)+"deg",ry:(x*3.2)+"deg",lx:(x*5)+"px",ly:(y*3)+"px"
    }))device.style.setProperty("--"+name,value);
    deviceFrame=moving?requestAnimationFrame(reflect):0;
  }
  function moveReflection(to){
    target=to;
    if(!deviceFrame)deviceFrame=requestAnimationFrame(reflect);
  }
  scene.addEventListener("pointermove",event=>{
    if(reduced.matches||!pointer.matches||event.pointerType!=="mouse")return;
    const box=scene.getBoundingClientRect();
    moveReflection({
      x:(event.clientX-box.left)/box.width-.5,
      y:(event.clientY-box.top)/box.height-.5
    });
  },{passive:true});
  scene.addEventListener("pointerleave",()=>moveReflection(rest),{passive:true});

  function drift(){
    footerFrame=0;
    if(reduced.matches)return;
    const box=footer.getBoundingClientRect();
    if(box.bottom<0||box.top>innerHeight)return;
    const progress=Math.min(1,Math.max(0,(innerHeight-box.top)/(innerHeight+box.height)));
    backdrop.style.setProperty("--drift",(progress-.5)*34+"px");
  }
  const cueFooter=()=>{if(!footerFrame&&!reduced.matches)footerFrame=requestAnimationFrame(drift);};
  addEventListener("scroll",cueFooter,{passive:true});
  addEventListener("resize",cueFooter,{passive:true});
  cueFooter();

  let sceneTitle=heading.textContent, titleMotion;
  new MutationObserver(()=>{
    const next=heading.textContent;
    if(next===sceneTitle)return;
    sceneTitle=next;
    if(reduced.matches)return;
    titleMotion?.cancel();
    titleMotion=heading.parentElement.animate([
      {opacity:.62,transform:"translateY(4px)",filter:"blur(2px)"},
      {opacity:1,transform:"none",filter:"none"}
    ],{duration:420,easing:"cubic-bezier(.16,1,.3,1)"});
  }).observe(heading,{childList:true,characterData:true,subtree:true});
  reduced.addEventListener("change",()=>{
    if(reduced.matches)titleMotion?.cancel();
    moveReflection(rest);
    cueFooter();
  });
})();
