"use strict";
(() => {
  const A=window.ShellArt, Care=ShellCare;
  const byId=id=>document.getElementById(id);
  const world=byId("world"), c=world.getContext("2d");
  const ui=Object.fromEntries(["primary","phase","description","windowState","floorHint","condition","growthBox","growth","growthLabel","archiveBox","archive","saveState","activities","resources","explore","draw","activityNote"].map(id=>[id,byId(id)]));
  const cradle=266, bed=113, bowl=493, edge=547;
  const labels={hatch:"捧暖石卵",feed:"喂一叶草药",play:"陪它玩",rest:"让它歇一会儿",explore:"去石隙探路",adopt:"迎接下一枚蛋"};
  const now=()=>performance.now()/1000;
  const seed=()=>crypto.getRandomValues(new Uint32Array(1))[0];
  let save,view,audio;
  let stored=null;
  try{stored=localStorage.getItem(Care.key);}catch{}
  const shared=Care.decode(stored);
  const previewSeed=new URLSearchParams(location.search).get("seed");
  const initialSeed=previewSeed!==null&&/^\d{1,10}$/.test(previewSeed)?Number(previewSeed)>>>0:seed();
  save=shared||Care.create(initialSeed);

  function rehome(){
    view={phase:save.pet?"home":"egg",t:now(),x:365,face:1,action:null,note:"",
      food:0,away:false,carry:false,placing:0};
    if(save.restUntil)view.x=bed;
  }
  function persist(){
    try{
      const latest=localStorage.getItem(Care.key);
      if(latest!==stored&&Care.decode(latest)){restore(latest);return;}
      stored=JSON.stringify(save);
      localStorage.setItem(Care.key,stored);
      ui.saveState.textContent="本机存档";
    }catch{ui.saveState.textContent="当前浏览器无法存档";}
  }
  function restore(raw){
    const other=Care.decode(raw);
    if(!other)return;
    save=other;stored=raw;Care.settle(save,Date.now());rehome();refresh();
  }
  addEventListener("storage",event=>{
    if(event.key===Care.key&&event.newValue!==stored)restore(event.newValue);
  });
  addEventListener("pagehide",()=>{
    Care.settle(save,Date.now());
    persist();
  });
  const scale=()=>save.bond>=Care.matureBond?1.12:save.bond>=8?1:.96;
  const busy=()=>Boolean(view.action&&view.action.kind!=="walk");
  function setText(el,value){if(el.textContent!==value)el.textContent=value;}
  function refresh(){
    const pet=save.pet,phase=view.phase,home=phase==="home";
    const resting=Boolean(save.restUntil);
    const suggested=!home&&phase!=="egg"||busy()?"":Care.recommend(save);
    const title={
      egg:"拾到一枚石卵",molt:"壳纹亮了起来",hatch:pet?.rig==="tail"?"一条尾巴先钻了出来":"一对触须先钻了出来",
      home:pet?Care.name(save.seed,pet):"",runner:"石隙探险"
    }[phase];
    const body={
      egg:"捧暖它，看看哪一只异兽会从壳里出来。",
      molt:"旧纹留了下来，壳底透出新的颜色。",
      hatch:pet?.rig==="tail"?"它用尾巴撑开半片石壳。":"它顶开了头上的整片石壳。",
      home:view.note||(resting?"它蜷在苔床上，呼吸渐渐平稳。":"点碗喂食，点苔床休息，点异兽陪它玩。"),
      runner:"点按画面或按空格跳跃，收集石露，避开石块。"
    }[phase];
    setText(ui.phase,title);
    setText(ui.description,body);
    setText(ui.condition,home?Care.shapeNames[pet.rig][pet.shape]+Care.families[pet.rig]:"石卵");
    setText(ui.windowState,home?Care.name(save.seed,pet):phase==="egg"?"石卵":"正在孵化");
    setText(ui.floorHint,home?"食碗 · 喂食　苔床 · 休息　异兽 · 陪玩":phase==="runner"?"点按画面或按空格跳跃。":"点按石卵也可以开始孵化。");
    ui.growthBox.hidden=!home;
    ui.activities.hidden=!home;
    setText(ui.resources,"石露 "+save.resources+" · 宝物 "+save.draws);
    ui.explore.disabled=busy()||resting;
    ui.draw.disabled=busy()||resting||save.resources<3;
    ui.growth.value=save.bond;
    setText(ui.growthLabel,home?Care.growth(save):"");
    ui.primary.hidden=!suggested;
    setText(ui.primary,labels[suggested]||"");
    ui.primary.dataset.command=suggested;
    ui.archiveBox.hidden=!save.archive.length;
    const recent=save.archive.slice(-4).map(p=>p.name+" · "+Care.families[p.shape.split("-")[0]]);
    if(ui.archive.textContent!==recent.join("")){
      ui.archive.replaceChildren(...recent.map(text=>Object.assign(document.createElement("li"),{textContent:text})));
    }
  }
  function setPhase(phase,t=now()){view.phase=phase;view.t=t;refresh();}
  function sound(hz,seconds=.23,volume=.035){
    try{
      audio??=new AudioContext();
      if(audio.state==="suspended")audio.resume().catch(()=>{});
      const t=audio.currentTime;
      const osc=audio.createOscillator(),g=audio.createGain();
      osc.frequency.setValueAtTime(hz,t);
      osc.frequency.exponentialRampToValueAtTime(hz*.72,t+seconds);
      g.gain.setValueAtTime(volume,t);
      g.gain.exponentialRampToValueAtTime(.001,t+seconds);
      osc.connect(g);g.connect(audio.destination);osc.start(t);osc.stop(t+seconds);
    }catch{}
  }
  function move(to,t=now(),kind="walk",done){
    const from=view.x,dist=Math.abs(to-from);
    if(dist<2){view.action=null;done?.(t);return;}
    view.face=Math.sign(to-from);
    const minimum=kind==="firstWalk"?1:.36;
    view.action={kind,t,d:Math.max(minimum,dist/(save.pet.rig==="shell"?91:114)),from,to,dist,done};
  }
  function pose(kind,t,d,done){view.action={kind,t,d,done};}
  function commit(delta,note){
    Care.settle(save,Date.now());
    Care.change(save,delta);
    view.note=note;
    persist();refresh();
  }
  function dispatch(command){
    if(command==="hatch"&&view.phase==="egg"){
      Care.finishHatch(save);
      persist();sound(167);setPhase("molt");return;
    }
    if(view.phase!=="home"||busy()||save.restUntil)return;
    if(command==="feed"){
      if(save.satiety>=96)return;
      view.food=1;view.note="把新摘的石缝草放进碗里。";
      const shell=save.pet.rig==="shell",base=shell?399:434;
      const reach=(bowl-base+(save.pet.head-1)*(shell?27:37))*scale();
      move(bowl-reach,now(),"toFood",t=>{
        view.face=1;
        pose("feed",t,shell?2.05:1.68,()=>{
          view.food=0;
          commit({satiety:35,bond:3},"它熟悉了你递来的草药。");
        });
      });
    } else if(command==="play"){
      if(save.satiety<43||save.energy<32){view.note="它想先吃点东西或歇一会儿。";refresh();return;}
      sound(229);
      view.note=save.pet.mood==="shy"?"它先缩了一下，再慢慢探头。":"它凑到窗边，追着你的手指看。";
      pose(save.pet.mood,now(),1.2,()=>commit({satiety:-13,energy:-19,bond:5},"它认得这个陪玩的手势了。"));
    } else if(command==="rest"){
      if(save.energy>=92)return;
      view.note="它沿着石面走回苔床。";
      move(bed,now(),"toBed",()=>{
        save.restUntil=Date.now()+6500;
        view.note="它蜷在苔床上，呼吸渐渐平稳。";
        persist();refresh();
      });
    } else if(command==="explore"){
      if(!Care.canExplore(save)||save.trips>=2)return;
      startTrip();
    } else if(command==="adopt"&&Care.canAdopt(save)){
      let next=seed();
      while(next===save.seed)next=seed();
      save=Care.nextEgg(save,next,Date.now());
      rehome();
      sound(206);persist();refresh();return;
    }
    refresh();
  }
  ui.explore.addEventListener("click",()=>{
    if(view.phase!=="home"||busy()||save.restUntil)return;
    view.runner=ShellRunner.start(now());setPhase("runner");
    setText(ui.floorHint,"点按画面或按空格跳跃，收集石露，避开石块。");
  });
  ui.draw.addEventListener("click",()=>{
    if(save.resources<3||busy()||save.restUntil)return;
    save.resources-=3;save.draws++;
    const prizes=["苔晶","月纹石","暖光铜铃","古瓦碎片"];
    const prize=prizes[crypto.getRandomValues(new Uint32Array(1))[0]%prizes.length];
    setText(ui.activityNote,"抽到了"+prize+"，已收入旅囊。");
    Care.change(save,{bond:2});persist();refresh();
  });
  function startTrip(){
    view.note="它沿着石隙往更深处走。";
    move(edge,now(),"depart",t=>{
      view.away=true;
      pose("away",t,1.6,back=>{
        view.away=false;
        view.carry=!save.lamp;
        view.note=view.carry?"它叼回了一盏旧铜灯。":"它衔着一根磨旧的芦矛回来了。";
        move(view.carry?447:375,back,"return",t2=>{
          if(!view.carry){finishTrip(false);return;}
          view.face=1;
          pose("place",t2,1.05,()=>finishTrip(true));
        });
        refresh();
      });
    });
  }
  function finishTrip(lamp){
    save.trips++;
    save.lamp||=lamp;
    view.carry=false;view.placing=0;
    if(lamp)move(375);
    sound(252);
    commit({satiety:-14,energy:-21,bond:5},lamp
      ?"铜灯亮了，右边的湿石浮出一层暖光。":"旧芦矛卡进背侧，会陪它继续走。");
  }
  function time(){
    const settled=Care.settle(save,Date.now());
    if(settled){
      view.note="它醒了，在苔床上伸了个懒腰。";
      persist();
    }
    refresh();
  }
  setInterval(time,1000);
  document.addEventListener("visibilitychange",()=>{if(!document.hidden)time();});

  function compose(t){
    if(view.phase==="molt"&&t-view.t>=.94){
      sound(116);setPhase("hatch",t);
    }else if(view.phase==="hatch"&&t-view.t>=2.8){
      view.x=370;view.face=1;
      view.note="它踩了踩湿石，朝食碗迈出第一步。";
      move(416,t,"firstWalk",refresh);
      setPhase("home",t);
    }
    const action=view.action, a={t};
    if(view.phase!=="home")return a;
    if(save.restUntil){a.sleep=true;a.crouch=.48;a.dip=.42;return a;}
    if(save.satiety<51){a.dip=.47;a.crouch=.17;}
    if(!action)return a;
    const q=A.clamp((t-action.t)/action.d);
    const shell=save.pet.rig==="shell";
    if(action.to!==undefined){
      view.x=A.lerp(action.from,action.to,q);
      a.walk=action.dist*q/(shell?34:52);
      a.strength=Math.sin(A.clamp(q*5)*Math.PI/2)*Math.sin(A.clamp((1-q)*5)*Math.PI/2);
      if(!shell){
        const beat=a.walk*2%1;
        a.crouch=Math.sin(A.step(0,.28,beat)*Math.PI)*a.strength*.38;
        a.air=Math.sin(A.step(.19,.83,beat)*Math.PI)*a.strength*7;
        a.tailAir=Math.sin(A.step(.31,.98,beat)*Math.PI)*a.strength*7;
      }
    }else if(action.kind==="feed"){
      a.reach=A.step(.04,.34,q)*(1-A.step(.79,.99,q));
      a.dip=A.step(shell?.24:.14,.53,q)*(1-A.step(.80,1,q));
      a.dip+=Math.sin(q*57)*.11*A.step(.47,.66,q)*(1-A.step(.7,.83,q));
      view.food=1-A.step(.52,.8,q);
    }else if(action.kind==="shy"){
      a.startle=A.step(0,.12,q)*(1-A.step(.39,.62,q));
      a.reach=A.step(.56,.72,q)*(1-A.step(.85,1,q))*.52;
    }else if(action.kind==="curious"){
      a.lean=A.step(.04,.33,q)*(1-A.step(.73,1,q));
      a.reach=a.lean*.43;
    }else if(action.kind==="place"){
      view.placing=A.step(0,1,q);
      a.dip=Math.sin(q*Math.PI)*.27;
    }
    if(q>=1){view.action=null;action.done?.(t);refresh();}
    return a;
  }
  function frame(stamp){
    const t=stamp/1000;
    if(view.phase==="runner"){
      ShellRunner.step(view.runner,t);
      ShellRunner.draw(c,view.runner,save.pet,t);
      world.dataset.phase="runner";
      if(view.runner.finished){
        const found=view.runner.coins;
        save.resources=Math.min(9999,save.resources+found);
        save.trips++;save.lamp=true;
        Care.change(save,{energy:-12,satiety:-8,bond:3});
        view.note="探险归来，带回 "+found+" 枚石露。";
        persist();setPhase("home");
      }
      requestAnimationFrame(frame);return;
    }
    const a=compose(t);
    const phase=view.phase,age=t-view.t,pet=save.pet;
    A.room(c,t,{herb:view.food,lampOn:save.lamp,lampPlaced:save.lamp,trip:["depart","away","return"].includes(view.action?.kind)?1:0});
    if(phase==="egg")A.egg(c,cradle,ShellProfiles.initial(save.seed),t);
    else if(phase==="molt"){
      const p=A.step(0,.62,age);
      A.egg(c,cradle,p<.48?ShellProfiles.initial(save.seed):pet,t,p);
    }else if(phase==="hatch")A.egg(c,cradle,pet,t,1,A.clamp(age/2.8,.001,1));
    else if(!view.away){
      A.pet(c,view.x,A.ground+(a.lean||0)*6,pet,a,{facing:view.face,equipped:save.trips>=2,scale:scale()+(a.lean||0)*.04});
      if(view.carry)A.lamp(c,A.lerp(view.x+view.face*17,565,view.placing),A.ground-40*(1-view.placing),false);
    }
    const actionName=view.action?.kind||(save.restUntil?"sleep":"idle");
    if(world.dataset.phase!==phase)world.dataset.phase=phase;
    if(world.dataset.action!==actionName)world.dataset.action=actionName;
    if(world.dataset.rig!==(pet?.rig||""))world.dataset.rig=pet?.rig||"";
    requestAnimationFrame(frame);
  }
  ui.primary.addEventListener("click",()=>dispatch(ui.primary.dataset.command));
  world.addEventListener("pointerup",event=>{
    if(view.phase==="runner"){ShellRunner.jump(view.runner);return;}
    const box=world.getBoundingClientRect();
    const x=(event.clientX-box.left)/box.width*A.w;
    const y=(event.clientY-box.top)/box.height*A.h;
    if(view.phase==="egg"){
      if(Math.abs(x-cradle)<=67&&y>=A.ground-135&&y<=A.ground+20)dispatch("hatch");
      return;
    }
    if(view.phase!=="home"||busy()||save.restUntil)return;
    if(Math.abs(x-bowl)<45&&y>A.ground-37&&y<A.ground+18)dispatch("feed");
    else if(Math.abs(x-bed)<63&&y>A.ground-42&&y<A.ground+15)dispatch("rest");
    else if(Math.abs(x-view.x)<70&&y>A.ground-100&&y<A.ground+5)dispatch("play");
    else if(y>A.ground-125)move(A.clamp(x,123,edge));
  });
  world.addEventListener("keydown",e=>{
    if(view.phase==="runner"&&[" ","ArrowUp"].includes(e.key)){e.preventDefault();ShellRunner.jump(view.runner);return;}
    if(!["ArrowLeft","ArrowRight"].includes(e.key)||view.phase!=="home"||busy()||save.restUntil)return;
    e.preventDefault();move(A.clamp(view.x+(e.key==="ArrowLeft"?-67:67),123,edge));
  });
  const woke=Care.settle(save,Date.now());
  rehome();
  if(woke)view.note="它睡了一觉，抬头认出了你。";
  persist();
  refresh();
  requestAnimationFrame(frame);
})();
