"use strict";
(() => {
  const A=window.ShellArt, P=ShellProfiles;
  const get=id=>document.getElementById(id);
  const world=get("world"), c=world.getContext("2d");
  const ui=Object.fromEntries(["primary","secondary","tertiary","reset","phase","description","windowState","floorHint","journey","mode","modeNote","finds","lamp","spear"].map(id=>[id,get(id)]));
  const names={shell:"背壳兽",tail:"摆尾兽"};
  const bowlX=493, cradleX=266, benchStartX=370;
  const minX=123,maxX=547;
  const serviceURL=new URLSearchParams(location.search).get("service")||"";
  function api(path) {
    return new URL(path,serviceURL ? new URL(serviceURL,location.href) : location.href);
  }
  let available=false, ticket=0, state;
  const now=()=>performance.now()/1000;
  const randomSeed=()=>crypto.getRandomValues(new Uint32Array(1))[0];
  function fresh(seed=randomSeed()) {
    ticket++;
    state={seed,egg:P.initial(seed),pet:null,interactions:[],phase:"egg",began:now(),x:benchStartX,facing:1,
      action:null,bench:null,pending:false,message:"",herb:0,hunger:"",lampOn:false,lampPlaced:false,
      equipped:false,finds:false,trip:0,away:false,carrying:false,placeProgress:0,lastGesture:null};
    refresh();
  }
  const phases=["egg","molt","hatch","home"];
  function phase(name,t=now()) {state.phase=name;state.began=t;refresh();}
  function button(el,text,fn) {
    el.hidden=!text;
    el.textContent=text||"";
    el.onclick=fn||null;
    el.disabled=state.pending;
  }
  function refresh() {
    const index=phases.indexOf(state.phase);
    [...ui.journey.children].forEach((li,i)=>{
      li.classList.toggle("done",i<index);
      if(i===index)li.setAttribute("aria-current","step");else li.removeAttribute("aria-current");
    });
    ui.windowState.textContent=["石卵","壳纹亮起","正在破壳",names[state.pet?.rig]||"归巢"][index];
    ui.floorHint.textContent=index===3?"点按地面或使用方向键，引它走动":"孵化后可点按地面，引它走动";
    ui.mode.value=ui.mode.value==="ai"?"ai":"sim";
    ui.modeNote.textContent=state.bench?"标杆回放 · 固定造型":ui.mode.value==="ai"
      ?available?"真实 AI · 互动记录送往生成服务。":"真实 AI · 生成服务尚未连接。"
      :"模拟模式 · 互动会改变孵化造型。";
    ui.finds.hidden=!state.finds;
    button(ui.tertiary);
    if(state.phase==="egg") {
      ui.phase.textContent=state.pending?"听取壳内回应":state.interactions.length?"壳中有了回应":"石卵微温";
      ui.description.textContent=state.message||(state.interactions.length===1?"再留一次动静，看看它会怎样变壳。":"壳面有一对细纹。捧暖或轻叩，留下它最先记住的动静。");
      button(ui.primary,"捧暖石卵",()=>interact("warm"));
      button(ui.secondary,"轻叩两声",()=>interact("tap"));
    } else if(state.phase==="molt") {
      ui.phase.textContent="旧纹仍在";
      ui.description.textContent=state.bench?"看看哪一个部位先钻出石壳。":"新壳沿旧纹生长。等它准备好，托住石卵。";
      button(ui.primary,"托住石卵",hatch);
      button(ui.secondary);
    } else if(state.phase==="hatch") {
      ui.phase.textContent=state.pet.rig==="shell"?"有触须探出来":"长尾探出壳沿";
      ui.description.textContent=state.pet.rig==="shell"?"它贴着石面，用力拱起顶上的整片旧壳。":"它用尾梢撑住地面，把身体从壳里推出来。";
      button(ui.primary);button(ui.secondary);
    } else {
      const action=state.action?.kind;
      ui.phase.textContent=action==="feed"?"碗里有草香":state.hunger||names[state.pet.rig]+"回家了";
      ui.description.textContent=state.message||(action==="firstWalk"
        ?"它把脚掌按在湿石上，迈出第一步。":"旧纹留在它身上。放一叶草药，或点点窗边试试。");
      button(ui.primary,"喂一叶草药",feed);
      button(ui.secondary,"轻叩窗沿",knock);
      if(!state.finds)button(ui.tertiary,"去石隙探路",adventure);
      button(ui.lamp,state.lampPlaced?state.lampOn?"熄灭铜灯":"点亮铜灯":"安放铜灯",placeLamp);
      button(ui.spear,state.equipped?"收起芦矛":"装备芦矛",equip);
      for(const key of ["primary","secondary","tertiary","lamp","spear"])ui[key].disabled=busy();
    }
  }
  async function serviceStatus() {
    if(!serviceURL&&(location.protocol==="file:"||location.hostname.endsWith(".github.io")))return;
    try {
      const r=await fetch(api("api/status"),{signal:AbortSignal.timeout(2500)});
      available=r.ok&&(await r.json()).available===true;
    } catch {available=false;}
    refresh();
  }
  async function requestProfile(seed,interactions) {
    const r=await fetch(api("api/generate"),{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({seed,interactions}),signal:AbortSignal.timeout(16000)});
    if(!r.ok)throw new Error("服务暂不可用");
    return P.validate(await r.json(),P.initial(seed));
  }
  async function interact(kind) {
    if(state.phase!=="egg"||state.pending)return;
    if(ui.mode.value==="ai"&&!available) {
      state.message="连接生成服务后可使用真实 AI。也可以切换模拟模式继续。";
      refresh();return;
    }
    state.interactions.push(kind);
    state.lastGesture={kind,t:now()};
    state.message=kind==="warm"?"壳慢慢回暖。再陪它片刻。":"壳在原地轻轻一颤。再留一次动静。";
    state.began=now()-.83;
    if(state.interactions.length<2){refresh();return;}
    sound(kind==="tap"?167:106,.23,.03);
    const run=++ticket;
    const {seed,interactions}=state;
    const source=ui.mode.value;
    state.pending=true; refresh();
    try {
      const result=source==="ai"?await requestProfile(seed,interactions):P.simulate(seed,interactions);
      if(run!==ticket)return;
      state.pet=result;state.pending=false;state.message="";
      phase("molt");
    } catch {
      if(run!==ticket)return;
      state.interactions.pop();state.pending=false;
      state.message="本次生成未完成。再试一次，或切换模拟模式。";refresh();
    }
  }
  function benchmark(rig) {
    fresh();
    state.bench=rig;state.egg={...P.benchmarks[rig]};
    state.pet={...P.benchmarks[rig],eggForm:(state.egg.eggForm+1)%3};
    state.began=now();
    refresh();
    const run=ticket;
    setTimeout(()=>{if(run!==ticket||state.phase!=="egg")return;phase("molt");},650);
    setTimeout(()=>{if(run===ticket&&state.phase==="molt")hatch();},1750);
  }
  function hatch() {
    if(state.phase!=="molt")return;
    sound(112,.22,.04);
    phase("hatch");
  }
  function duration(dist) {
    return Math.max(.47,dist/(state.pet.rig==="shell"?52:75));
  }
  function move(x,t=now(),kind="walk",then=null) {
    const dest=A.clamp(x,minX,maxX);
    const dist=Math.abs(dest-state.x);
    if(dist<3){if(then)then(t);return;}
    state.facing=Math.sign(dest-state.x);
    state.action={kind,t,d:duration(dist),from:state.x,to:dest,then,dist};
  }
  function foodAt(t) {
    state.facing=1;
    state.action={kind:"feed",t,d:state.pet.rig==="shell"?2.36:1.95};
    state.hunger="";
    refresh();
  }
  function feed() {
    if(state.phase!=="home"||busy())return;
    state.herb=1;
    state.message=state.pet.rig==="shell"?"它先用触须试探碗沿。":"它弯下细颈，把叶片叼起来。";
    const base=state.pet.rig==="shell"?399:434;
    const delta=(state.pet.head-1)*(state.pet.rig==="shell"?27:37);
    move(base-delta,now(),"toFood",foodAt);
    refresh();
  }
  function knock() {
    if(state.phase!=="home"||busy())return;
    sound(189,.13,.04);
    if(state.pet.mood==="shy") {
      state.action={kind:"shy",t:now(),d:1.48};
      state.message="它缩进壳沿，听了一会儿才探头。";
    } else {
      state.action={kind:"curious",t:now(),d:1.12};
      state.message="它凑到窗边，想看看外头是谁。";
    }
    refresh();
  }
  function busy() {
    return Boolean(state.action?.then||["feed","away","place"].includes(state.action?.kind));
  }
  function adventure() {
    if(state.finds||busy())return;
    state.trip=1;
    state.message="它沿着潮湿的石缝，往窗外探去。";
    move(maxX,now(),"depart",t=>{
      state.away=true;
      state.action={kind:"away",t,d:1.35,then:reenter};
      refresh();
    });
    refresh();
  }
  function reenter(t) {
    state.away=false;
    state.carrying=true;
    state.message="它从石隙带回铜灯和一柄旧芦矛。";
    move(433,t,"return",()=>{
      state.finds=true;
      state.trip=0;
      refresh();
    });
    refresh();
  }
  function placeLamp() {
    if(!state.finds||busy())return;
    if(state.lampPlaced) {
      state.lampOn=!state.lampOn;
      state.message=state.lampOn?"灯芯亮起，右边的湿石泛出铜光。":"灯芯熄了，右侧回到微暗。";
      refresh();return;
    }
    state.message="它把铜灯挪到右边的空石台。";
    move(513,now(),"carry",t=>{
      state.facing=1;
      state.action={kind:"place",t,d:1.02,then:()=>{
        state.placeProgress=0;state.carrying=false;
        state.lampPlaced=true;state.lampOn=true;
        state.message="铜灯安在右角，照亮了一小块湿石。";
        move(438,now());
        sound(254,.19,.022);refresh();
      }};
      refresh();
    });
    refresh();
  }
  function equip() {
    if(!state.finds||busy())return;
    state.equipped=!state.equipped;
    state.message=state.equipped?"磨旧的芦矛卡在背侧，探出了背缘。":"它把芦矛收了起来。";
    refresh();
  }
  let audio;
  function sound(hz,length,volume) {
    if(!audio||audio.state!=="running")return;
    const t=audio.currentTime;
    const osc=audio.createOscillator(),gain=audio.createGain();
    osc.type="sine";osc.frequency.setValueAtTime(hz,t);osc.frequency.exponentialRampToValueAtTime(hz*.65,t+length);
    gain.gain.setValueAtTime(volume,t);gain.gain.exponentialRampToValueAtTime(.001,t+length);
    osc.connect(gain);gain.connect(audio.destination);osc.start(t);osc.stop(t+length);
  }
  addEventListener("pointerdown",()=>{
    try {audio??=new AudioContext(); if(audio.state==="suspended")audio.resume().catch(()=>{});}catch{}
  },{once:true});
  function compose(t) {
    const elapsed=t-state.began;
    const a={t};
    if(state.phase==="hatch"&&elapsed>=2.8) {
      state.x=benchStartX;state.facing=1;
      state.phase="home";state.began=t;
      state.hungryAt=t+23;
      move(421,t,"firstWalk");
      refresh();
    }
    if(state.phase==="home"&&state.hungryAt&&t>state.hungryAt&&!state.action) {
      state.hungryAt=0;
      state.hunger=state.pet.rig==="shell"?"它把背壳压低了":"它望向食碗";
      state.message="它在等一叶草药。";
      refresh();
    }
    if(state.hunger) {a.dip=.19+.09*Math.sin(t*2);a.crouch=.12;}
    const action=state.action;
    if(!action)return a;
    const dt=t-action.t,q=A.clamp(dt/action.d);
    if(action.to!==undefined) {
      state.x=A.lerp(action.from,action.to,q);
      const shell=state.pet.rig==="shell";
      const stride=shell?34:52;
      const strideOffset=action.dist<stride?.08:0;
      a.walk=action.dist*q/stride+strideOffset;
      a.strength=Math.sin(A.clamp(q*5)*Math.PI/2)*Math.sin(A.clamp((1-q)*5)*Math.PI/2);
      if(!shell) {
        const bounce=(a.walk*2)%1;
        a.crouch=Math.sin(A.step(0,.28,bounce)*Math.PI)*a.strength*.36;
        a.air=Math.sin(A.step(.19,.83,bounce)*Math.PI)*a.strength*7;
      }
    } else if(action.kind==="feed") {
      const shell=state.pet.rig==="shell";
      a.reach=A.step(.04,.34,q)*(1-A.step(.79,.99,q));
      a.dip=A.step(shell?.24:.14,.53,q)*(1-A.step(.80,1,q));
      a.dip+=Math.sin(q*57)*.12*A.step(.47,.66,q)*(1-A.step(.7,.83,q));
      state.herb=1-A.step(.52,.8,q);
    } else if(action.kind==="shy"){
      a.startle=A.step(0,.12,q)*(1-A.step(.39,.62,q));
      a.reach=A.step(.56,.72,q)*(1-A.step(.85,1,q))*.52;
    } else if(action.kind==="curious"){
      a.lean=A.step(.04,.33,q)*(1-A.step(.73,1,q));
      a.reach=a.lean*.43;
    } else if(action.kind==="place"){
      state.placeProgress=A.step(0,1,q);
      a.dip=Math.sin(q*Math.PI)*.27;
    }
    if(q>=1) {
      state.action=null;
      if(action.kind==="feed") {
        state.hungryAt=t+35;
        state.message="草药吃完了，它舔了舔碗沿。";
        refresh();
      }
      if(action.kind==="firstWalk")refresh();
      if(action.then)action.then(t);
    }
    return a;
  }
  function frame(stamp) {
    const t=stamp/1000;
    const a=compose(t);
    A.room(c,t,{herb:state.herb,lampOn:state.lampOn,lampPlaced:state.lampPlaced,trip:state.trip});
    const elapsed=t-state.began;
    if(state.phase==="egg"){
      const event=state.lastGesture;
      const age=event?t-event.t:1;
      const shake=event?.kind==="tap"&&age<.56?Math.sin(age*48)*(1-age/.56)*5:0;
      A.egg(c,cradleX+shake,state.egg,t);
    } else if(state.phase==="molt"){
      const melt=A.step(0,.62,elapsed);
      const p=melt<.48?state.egg:state.pet;
      A.egg(c,cradleX,p,t,melt);
    } else if(state.phase==="hatch"){
      A.egg(c,cradleX,state.pet,t,1,A.clamp(elapsed/2.8,.001,1));
    } else {
      if(!state.away) {
        A.pet(c,state.x,A.ground+(a.lean||0)*6,state.pet,a,{
          facing:state.facing,equipped:state.equipped,scale:1+(a.lean||0)*.04
        });
        if(state.carrying){
          const p=state.placeProgress;
          const lift=state.pet.rig==="shell"?35:48;
          A.lamp(c,A.lerp(state.x+state.facing*17,565,p),A.ground-lift*(1-p)+Math.sin(p*Math.PI)*-9,false);
        }
      }
    }
    world.dataset.phase=state.phase;
    world.dataset.action=state.action?.kind||"idle";
    requestAnimationFrame(frame);
  }
  function canGuide() {
    return state.phase==="home"&&!busy();
  }
  world.addEventListener("pointerup",e=>{
    const r=world.getBoundingClientRect();
    if(canGuide())move((e.clientX-r.left)/r.width*A.w);
  });
  world.addEventListener("keydown",e=>{
    if(!["ArrowLeft","ArrowRight"].includes(e.key)||!canGuide())return;
    e.preventDefault();move(state.x+(e.key==="ArrowLeft"?-67:67));
  });
  ui.mode.addEventListener("change",()=>{fresh();if(ui.mode.value==="ai")serviceStatus();});
  ui.reset.onclick=()=>fresh();
  document.querySelectorAll("[data-rig]").forEach(el=>el.onclick=()=>benchmark(el.dataset.rig));
  // The query seed makes art review captures repeatable.
  const seedParam=new URLSearchParams(location.search).get("seed");
  fresh(seedParam!==null&&/^\d{1,10}$/.test(seedParam)?Number(seedParam)>>>0:randomSeed());
  serviceStatus();
  requestAnimationFrame(frame);
})();
